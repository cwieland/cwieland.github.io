using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PlayfieldEditor
{
	/// <summary>
	/// Summary description for PlayfieldName.
	/// </summary>
	public class PlayfieldNameDialog : System.Windows.Forms.Form
	{
		private string _newLabelName;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOk;
		private System.Windows.Forms.TextBox txtNewLabelName;
		private System.Windows.Forms.Label lblNewLabelName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public string NewLabelName
		{
			get
			{
				return _newLabelName;
			}
		}

		public PlayfieldNameDialog(string ExistingLabelName)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			_newLabelName = ExistingLabelName;
			txtNewLabelName.Text = _newLabelName;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOk = new System.Windows.Forms.Button();
			this.txtNewLabelName = new System.Windows.Forms.TextBox();
			this.lblNewLabelName = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(120, 40);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 3;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnOk
			// 
			this.btnOk.Location = new System.Drawing.Point(24, 40);
			this.btnOk.Name = "btnOk";
			this.btnOk.TabIndex = 2;
			this.btnOk.Text = "&Ok";
			this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
			// 
			// txtNewLabelName
			// 
			this.txtNewLabelName.Location = new System.Drawing.Point(120, 8);
			this.txtNewLabelName.MaxLength = 8;
			this.txtNewLabelName.Name = "txtNewLabelName";
			this.txtNewLabelName.Size = new System.Drawing.Size(112, 20);
			this.txtNewLabelName.TabIndex = 1;
			this.txtNewLabelName.Text = "";
			// 
			// lblNewLabelName
			// 
			this.lblNewLabelName.Location = new System.Drawing.Point(8, 8);
			this.lblNewLabelName.Name = "lblNewLabelName";
			this.lblNewLabelName.Size = new System.Drawing.Size(96, 23);
			this.lblNewLabelName.TabIndex = 0;
			this.lblNewLabelName.Text = "New Label Name";
			this.lblNewLabelName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// PlayfieldNameDialog
			// 
			this.AcceptButton = this.btnOk;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(240, 70);
			this.ControlBox = false;
			this.Controls.Add(this.lblNewLabelName);
			this.Controls.Add(this.txtNewLabelName);
			this.Controls.Add(this.btnOk);
			this.Controls.Add(this.btnCancel);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "PlayfieldNameDialog";
			this.Text = "Change Playfield Label";
			this.TopMost = true;
			this.ResumeLayout(false);

		}
		#endregion

		private void btnOk_Click(object sender, System.EventArgs e)
		{
			if (ValidateFormat(txtNewLabelName.Text))
			{
				_newLabelName = txtNewLabelName.Text;
				this.DialogResult = DialogResult.OK;
				this.Close();
			}
			else
			{
				MessageBox.Show("Label may only contain uppercase or lowercase letters.", "Invalid Format", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private bool ValidateFormat(string text)
		{
			bool isValid = text.Length > 0;
			if (isValid)
			{
				foreach (char c in text.ToLower().ToCharArray())
				{
					if (c < 'a' || c > 'z')
					{
						isValid = false;
						break;
					}
				}
			}

			return isValid;
		}
	}
}
