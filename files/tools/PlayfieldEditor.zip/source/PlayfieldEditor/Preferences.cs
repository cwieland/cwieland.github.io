namespace PlayfieldEditor
{
	#region Namespaces
	using System;
	#endregion

	/// <summary>
	/// This class is used to store the preferences
	/// </summary>
	public class Preferences
	{
		#region Private Fields
		private static bool _outputColorData;						// Output the color data
		private static bool _reversedOrder;							// Output data in reversed order
		private static bool _outputHexData;							// Output data in hexadecimal
		private static bool _palVideo;								// Use PAL video
		private static byte _defaultMode;							// Default playfield mode
		#endregion
		
		#region Properties
		/// <summary>
		/// Whether the color data is outputted or not
		/// </summary>
		public static bool OutputColorData
		{
			get 
			{
				return _outputColorData;
			}
			set
			{
				_outputColorData = value;
			}
		}

		/// <summary>
		/// Whether the data should be outputted in the reversed order (columns)
		/// </summary>
		public static bool ReversedOrder
		{
			get
			{
				return _reversedOrder;
			}
			set
			{
				_reversedOrder = value;
			}
		}

		/// <summary>
		/// Whether the data should be outputted in hex or binary format
		/// </summary>
		public static bool OutputHexData
		{
			get
			{
				return _outputHexData;
			}
			set
			{
				_outputHexData = value;
			}
		}

		/// <summary>
		/// Whether the palette used is PAL or NTSC format
		/// </summary>
		public static bool PalVideo
		{
			get
			{
				return _palVideo;
			}
			set
			{
				_palVideo = value;
			}
		}

		/// <summary>
		/// Gets or sets the default playfield mode
		/// </summary>
		public static byte DefaultMode
		{
			get
			{
				return _defaultMode;
			}
			set
			{
				_defaultMode = value;
			}
		}
		#endregion

		#region Public Methods
		public static void GetPreferences()
		{
			try
			{
				Microsoft.Win32.RegistryKey key;
				key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\\Junkosoft\\PlayfieldEditor", false);
				_outputColorData = bool.Parse(key.GetValue("OutputColorData").ToString().ToLower());
				_outputHexData = bool.Parse(key.GetValue("OutputHexData").ToString().ToLower());
				_palVideo = bool.Parse(key.GetValue("PalVideo").ToString().ToLower());
				_reversedOrder = bool.Parse(key.GetValue("ReversedOrder").ToString().ToLower());
				_defaultMode = byte.Parse(key.GetValue("DefaultMode").ToString().ToLower());
			}
			catch
			{
				DoPreferencesReset();
			}
		}

		public static void SetPreferences()
		{
			Microsoft.Win32.RegistryKey key;
			key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\\Junkosoft\\PlayfieldEditor", true);
			key.SetValue("OutputColorData", _outputColorData);
			key.SetValue("OutputHexData", _outputHexData);
			key.SetValue("PalVideo", _palVideo);
			key.SetValue("ReversedOrder", _reversedOrder);
			key.SetValue("DefaultMode", _defaultMode);
		}
		#endregion

		#region Private Methods
		private static void DoPreferencesReset()
		{
			_outputColorData = false;
			_outputHexData = false;
			_palVideo = false;
			_reversedOrder = false;
			_defaultMode = 0;
			Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Software\\Junkosoft\\PlayfieldEditor");
			SetPreferences();
		}
		#endregion
	}
}