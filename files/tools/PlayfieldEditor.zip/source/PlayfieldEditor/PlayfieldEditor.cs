// TODO:
// Implement flag for split playfield colors P0/left, P1/right (CTRLPF SCORE BIT Set)
// Implement option to set all forecolor and backcolor for all rows (dialog box?)
// Maybe remove option to set the colors row by row (at least the background)

using System;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace PlayfieldEditor
{
	public struct Playfield
	{
		public float Version;
		public string Name;
		public byte[,] Data;
		public byte Mode;
		public bool ScoreBit;
		public byte P0Color;
		public byte P1Color;
	}

	/// <summary>
	/// Junkosoft Playfield Editor Main Form
	/// </summary>
	public class PlayfieldEditorForm : System.Windows.Forms.Form
	{
		private const byte CellWidth = 15;
		private const byte CellHeight = 8;
		private const int GridForeColorLength = 625;
		private const int GridBackColorLength = 650;
		private const int GridSize = 600;
		private const int SmallGridX = 660;
		private const int SmallGridY = 315;
		private const int SmallCellWidth = 3;
		private const int SmallCellHeight = 1;
		private const int NumRows = 64;

		private string Path;
		private bool IsDirty;
		private Playfield CurrentPlayfield;
		private Color[,] Palette;
		private byte[] RowColor;
		private byte[] BackgroundColor;

		private System.Windows.Forms.Label lblVideoType;
		private System.Windows.Forms.Label lblNew;
		private System.Windows.Forms.Label lblOpen;
		private System.Windows.Forms.Label lblSave;
		private System.Windows.Forms.Label lblChangeLabel;
		private System.Windows.Forms.Label lblOutputAsmSource;
		private System.Windows.Forms.Label lblOutputType;
		private System.Windows.Forms.Label lblDataOrder;
		private System.Windows.Forms.Label lblOutputDataType;
		private System.Windows.Forms.Label lblPlayfieldLabel;
		private System.Windows.Forms.Label lblExit;
		private System.Windows.Forms.Label lblTitle;
		private System.Windows.Forms.SaveFileDialog SavePlayfieldFile;
		private System.Windows.Forms.SaveFileDialog SaveAsmSource;
		private System.Windows.Forms.OpenFileDialog OpenPlayfieldFile;
		private System.Windows.Forms.Label lblDrawMode;
		private System.ComponentModel.IContainer components;

		public PlayfieldEditorForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			Preferences.GetPreferences();
			CreateEmptyPlayfield();
			InitializePalette();
			InitializeRowColor();
			SetLabelValues();
		}

		public PlayfieldEditorForm(string path) : this()
		{
			//
			// Required for Windows Form Designer support
			//
			ReadPlayfieldFile(path);
			Path = path;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// Gets the current version of the application
		/// </summary>
		private Version CurrentVersion
		{
			get
			{
				return new Version(Application.ProductVersion);
			}
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.lblVideoType = new System.Windows.Forms.Label();
			this.lblNew = new System.Windows.Forms.Label();
			this.lblOpen = new System.Windows.Forms.Label();
			this.lblSave = new System.Windows.Forms.Label();
			this.lblChangeLabel = new System.Windows.Forms.Label();
			this.lblOutputAsmSource = new System.Windows.Forms.Label();
			this.lblDrawMode = new System.Windows.Forms.Label();
			this.lblOutputType = new System.Windows.Forms.Label();
			this.lblDataOrder = new System.Windows.Forms.Label();
			this.lblOutputDataType = new System.Windows.Forms.Label();
			this.lblPlayfieldLabel = new System.Windows.Forms.Label();
			this.lblExit = new System.Windows.Forms.Label();
			this.lblTitle = new System.Windows.Forms.Label();
			this.SavePlayfieldFile = new System.Windows.Forms.SaveFileDialog();
			this.SaveAsmSource = new System.Windows.Forms.SaveFileDialog();
			this.OpenPlayfieldFile = new System.Windows.Forms.OpenFileDialog();
			this.SuspendLayout();
			// 
			// lblVideoType
			// 
			this.lblVideoType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblVideoType.Location = new System.Drawing.Point(792, 312);
			this.lblVideoType.Name = "lblVideoType";
			this.lblVideoType.Size = new System.Drawing.Size(12, 56);
			this.lblVideoType.TabIndex = 10;
			this.lblVideoType.Text = "NTSC";
			this.lblVideoType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblVideoType.Click += new System.EventHandler(this.lblVideoType_Click);
			// 
			// lblNew
			// 
			this.lblNew.BackColor = System.Drawing.Color.Transparent;
			this.lblNew.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblNew.Location = new System.Drawing.Point(656, 1);
			this.lblNew.Name = "lblNew";
			this.lblNew.Size = new System.Drawing.Size(144, 25);
			this.lblNew.TabIndex = 0;
			this.lblNew.Text = "New";
			this.lblNew.Click += new System.EventHandler(this.lblNew_Click);
			// 
			// lblOpen
			// 
			this.lblOpen.BackColor = System.Drawing.Color.Transparent;
			this.lblOpen.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblOpen.Location = new System.Drawing.Point(656, 31);
			this.lblOpen.Name = "lblOpen";
			this.lblOpen.Size = new System.Drawing.Size(144, 25);
			this.lblOpen.TabIndex = 1;
			this.lblOpen.Text = "Open";
			this.lblOpen.Click += new System.EventHandler(this.lblOpen_Click);
			// 
			// lblSave
			// 
			this.lblSave.BackColor = System.Drawing.Color.Transparent;
			this.lblSave.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblSave.Location = new System.Drawing.Point(656, 61);
			this.lblSave.Name = "lblSave";
			this.lblSave.Size = new System.Drawing.Size(144, 25);
			this.lblSave.TabIndex = 2;
			this.lblSave.Text = "Save";
			this.lblSave.Click += new System.EventHandler(this.lblSave_Click);
			// 
			// lblChangeLabel
			// 
			this.lblChangeLabel.BackColor = System.Drawing.Color.Transparent;
			this.lblChangeLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblChangeLabel.Location = new System.Drawing.Point(656, 91);
			this.lblChangeLabel.Name = "lblChangeLabel";
			this.lblChangeLabel.Size = new System.Drawing.Size(144, 25);
			this.lblChangeLabel.TabIndex = 3;
			this.lblChangeLabel.Text = "Change Label";
			this.lblChangeLabel.Click += new System.EventHandler(this.lblChangeLabel_Click);
			// 
			// lblOutputAsmSource
			// 
			this.lblOutputAsmSource.BackColor = System.Drawing.Color.Transparent;
			this.lblOutputAsmSource.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblOutputAsmSource.Location = new System.Drawing.Point(656, 121);
			this.lblOutputAsmSource.Name = "lblOutputAsmSource";
			this.lblOutputAsmSource.Size = new System.Drawing.Size(144, 25);
			this.lblOutputAsmSource.TabIndex = 4;
			this.lblOutputAsmSource.Text = "Output Asm Source";
			this.lblOutputAsmSource.Click += new System.EventHandler(this.lblOutputAsmSource_Click);
			// 
			// lblDrawMode
			// 
			this.lblDrawMode.BackColor = System.Drawing.Color.Transparent;
			this.lblDrawMode.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblDrawMode.Location = new System.Drawing.Point(656, 151);
			this.lblDrawMode.Name = "lblDrawMode";
			this.lblDrawMode.Size = new System.Drawing.Size(144, 25);
			this.lblDrawMode.TabIndex = 5;
			this.lblDrawMode.Text = "Non-Reflected";
			this.lblDrawMode.Click += new System.EventHandler(this.lblDrawMode_Click);
			// 
			// lblOutputType
			// 
			this.lblOutputType.BackColor = System.Drawing.Color.Transparent;
			this.lblOutputType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblOutputType.Location = new System.Drawing.Point(656, 181);
			this.lblOutputType.Name = "lblOutputType";
			this.lblOutputType.Size = new System.Drawing.Size(144, 25);
			this.lblOutputType.TabIndex = 6;
			this.lblOutputType.Text = "Playfield Data Only";
			this.lblOutputType.Click += new System.EventHandler(this.lblOutputType_Click);
			// 
			// lblDataOrder
			// 
			this.lblDataOrder.BackColor = System.Drawing.Color.Transparent;
			this.lblDataOrder.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblDataOrder.Location = new System.Drawing.Point(656, 211);
			this.lblDataOrder.Name = "lblDataOrder";
			this.lblDataOrder.Size = new System.Drawing.Size(144, 25);
			this.lblDataOrder.TabIndex = 7;
			this.lblDataOrder.Text = "Nonreversed Order";
			this.lblDataOrder.Click += new System.EventHandler(this.lblDataOrder_Click);
			// 
			// lblOutputDataType
			// 
			this.lblOutputDataType.BackColor = System.Drawing.Color.Transparent;
			this.lblOutputDataType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblOutputDataType.Location = new System.Drawing.Point(656, 241);
			this.lblOutputDataType.Name = "lblOutputDataType";
			this.lblOutputDataType.Size = new System.Drawing.Size(144, 25);
			this.lblOutputDataType.TabIndex = 8;
			this.lblOutputDataType.Text = "Binary Data";
			this.lblOutputDataType.Click += new System.EventHandler(this.lblOutputDataType_Click);
			// 
			// lblPlayfieldLabel
			// 
			this.lblPlayfieldLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblPlayfieldLabel.Location = new System.Drawing.Point(696, 392);
			this.lblPlayfieldLabel.Name = "lblPlayfieldLabel";
			this.lblPlayfieldLabel.Size = new System.Drawing.Size(64, 16);
			this.lblPlayfieldLabel.TabIndex = 11;
			// 
			// lblExit
			// 
			this.lblExit.BackColor = System.Drawing.Color.Transparent;
			this.lblExit.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblExit.Location = new System.Drawing.Point(656, 271);
			this.lblExit.Name = "lblExit";
			this.lblExit.Size = new System.Drawing.Size(144, 25);
			this.lblExit.TabIndex = 9;
			this.lblExit.Text = "Exit";
			this.lblExit.Click += new System.EventHandler(this.lblExit_Click);
			// 
			// lblTitle
			// 
			this.lblTitle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTitle.Location = new System.Drawing.Point(680, 480);
			this.lblTitle.Name = "lblTitle";
			this.lblTitle.Size = new System.Drawing.Size(104, 32);
			this.lblTitle.TabIndex = 12;
			this.lblTitle.Text = "Junkosoft Playfield Editor";
			this.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// SavePlayfieldFile
			// 
			this.SavePlayfieldFile.DefaultExt = "spr";
			this.SavePlayfieldFile.Filter = "Playfield Files (*.plf)|*.plf|All Files (*.*)|*.*";
			this.SavePlayfieldFile.Title = "Save Playfield Data As";
			// 
			// SaveAsmSource
			// 
			this.SaveAsmSource.DefaultExt = "s";
			this.SaveAsmSource.Filter = "Assembly Source (*.s)|*.s|All Files (*.*)|*.*";
			this.SaveAsmSource.OverwritePrompt = false;
			this.SaveAsmSource.Title = "Save Assembly Source As";
			// 
			// OpenPlayfieldFile
			// 
			this.OpenPlayfieldFile.DefaultExt = "spr";
			this.OpenPlayfieldFile.Filter = "Playfield Files (*.plf)|*.plf|All Files (*.*)|*.*";
			this.OpenPlayfieldFile.Title = "Open Playfield Data";
			// 
			// PlayfieldEditorForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(7, 14);
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(816, 514);
			this.Controls.Add(this.lblTitle);
			this.Controls.Add(this.lblExit);
			this.Controls.Add(this.lblPlayfieldLabel);
			this.Controls.Add(this.lblOutputDataType);
			this.Controls.Add(this.lblDataOrder);
			this.Controls.Add(this.lblOutputType);
			this.Controls.Add(this.lblDrawMode);
			this.Controls.Add(this.lblOutputAsmSource);
			this.Controls.Add(this.lblChangeLabel);
			this.Controls.Add(this.lblSave);
			this.Controls.Add(this.lblOpen);
			this.Controls.Add(this.lblNew);
			this.Controls.Add(this.lblVideoType);
			this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.ForeColor = System.Drawing.Color.White;
			this.MaximizeBox = false;
			this.Name = "PlayfieldEditorForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Junkosoft Playfield Editor for Atari 2600";
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PlayfieldEditorForm_MouseDownOrMove);
			this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PlayfieldEditorForm_MouseDownOrMove);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) 
		{
			if (args.Length == 0)
			{
				Application.Run(new PlayfieldEditorForm());
			}
			else
			{
				Application.Run(new PlayfieldEditorForm(args[0]));
			}
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{

		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics current = this.CreateGraphics();
			Pen drawingPen = new Pen(Color.White, 1);

			for (int x = 0; x <= 40 ; x++)
			{				 
				Point start = new Point(x * CellWidth, 0);
				Point end = new Point(x * CellWidth, CellHeight * NumRows);
				current.DrawLine(drawingPen, start, end);
			}

			for (int y = 0; y <= NumRows; y++)
			{
				Point start = new Point(0, y * CellHeight);
				Point end = new Point(40 * CellWidth, y * CellHeight);
				current.DrawLine(drawingPen, start, end);
			}

			for (int y = 0; y <= NumRows; y++)
			{
				Point start = new Point(40 * CellWidth, y * CellHeight);
				Point end = new Point(GridBackColorLength, y * CellHeight);
				current.DrawLine(drawingPen, start, end);
			}

			Point p1 = new Point(GridForeColorLength, 0);
			Point p2 = new Point(GridForeColorLength, CellHeight * NumRows);
			current.DrawLine(drawingPen, p1, p2);

			p1 = new Point(GridBackColorLength, 0);
			p2 = new Point(GridBackColorLength, CellHeight * NumRows);
			current.DrawLine(drawingPen, p1, p2);

			p1 = new Point(this.Width, 0);
			p2 = new Point(this.Width, 300);
			current.DrawLine(drawingPen, p1, p2);

			for (int y = 0; y <= 10; y++)
			{
				Point start = new Point(GridBackColorLength, y * 30);
				Point end = new Point(this.Width, y * 30);
				current.DrawLine(drawingPen, start, end);
			}

			// Draw the playfield data
			for (int y = 0; y < NumRows; y++)
			{
				// Draw playfield data row
				for (int x = 0; x < 40; x++)
				{
					DrawCell(x,y,current);
				}
				DrawRowColorCell(y,current);
			}

			drawingPen.Dispose();
			current.Dispose();
			lblPlayfieldLabel.Text = CurrentPlayfield.Name;
		}

		private void PlayfieldEditorForm_MouseDownOrMove(object sender, MouseEventArgs e)
		{
			Graphics g = this.CreateGraphics();

			for (int y = 0; y < NumRows; y++)
			{
				for (int x = 0; x <= 40; x++)
				{
					if (x < 40)
					{
						// Check rows in cell
						if (e.X > x * CellWidth && e.X < (x+1) * CellWidth && e.Y > y * CellHeight &&
							e.Y < (y+1) * CellHeight)
						{
							if (e.Button == MouseButtons.Left)
							{
								CurrentPlayfield.Data[x,y] = RowColor[y];
								DrawCell(x,y,g);
								IsDirty = true;

								switch (CurrentPlayfield.Mode)
								{
									case PlayfieldModes.Reflected:
										if (x < 20)
										{
											CurrentPlayfield.Data[x+20,y] = RowColor[y];
											DrawCell(x+20,y,g);
										}
										else
										{
											CurrentPlayfield.Data[x-20,y] = RowColor[y];
											DrawCell(x-20,y,g);
										}
										break;
									case PlayfieldModes.Mirrored:
										CurrentPlayfield.Data[39-x,y] = RowColor[y];
										DrawCell(39-x,y,g);
										break;
								}

							}
							else if (e.Button == MouseButtons.Right)
							{
								CurrentPlayfield.Data[x,y] = 0x00;
								DrawCell(x,y,g);
								IsDirty = true;
								
								switch (CurrentPlayfield.Mode)
								{
									case PlayfieldModes.Reflected:
										if (x < 20)
										{
											CurrentPlayfield.Data[x+20,y] = 0x00;
											DrawCell(x+20,y,g);
										}
										else
										{
											CurrentPlayfield.Data[x-20,y] = 0x00;
											DrawCell(x-20,y,g);
										}
										break;
									case PlayfieldModes.Mirrored:
										CurrentPlayfield.Data[39-x,y] = 0x00;
										DrawCell(39-x,y,g);
										break;
								}
							}
						}
					}
					else
					{
						if (e.X > GridSize && e.X < GridForeColorLength && e.Y > y * CellHeight &&
							e.Y < (y+1) * CellHeight)
						{
							// Forecolor button clicked
							switch (e.Button)
							{
								case MouseButtons.Left:
									// Increment the color of the row
									if (RowColor[y] == 127)
									{
										RowColor[y] = 1;
									}
									else
									{									
										RowColor[y]++;
									}

									for (int cellIndex = 0; cellIndex < 40; cellIndex++)
									{
										if (CurrentPlayfield.Data[cellIndex,y] > 0x00)
										{
											CurrentPlayfield.Data[cellIndex,y] = RowColor[y];
										}
										DrawCell(cellIndex,y,g);
									}

									DrawRowColorCell(y,g);
									IsDirty = true;
									break;
								case MouseButtons.Right:
									// Decrement the color of the row
									if (RowColor[y] == 1)
									{
										RowColor[y] = 127;
									}
									else
									{
										RowColor[y]--;
									}

									for (int cellIndex = 0; cellIndex < 40; cellIndex++)
									{
										if (CurrentPlayfield.Data[cellIndex,y] > 0x00)
										{
											CurrentPlayfield.Data[cellIndex,y] = RowColor[y];
										}
										DrawCell(cellIndex,y,g);
									}

									DrawRowColorCell(y,g);
									IsDirty = true;
									break;
							}
							
						}
						else if (e.X > GridForeColorLength && e.X < GridBackColorLength && e.Y > y * CellHeight &&
							e.Y < (y+1) * CellHeight)
						{
							// Background color button clicked
							switch (e.Button)
							{
								case MouseButtons.Left:
									// Increment the background color of the row
									if (BackgroundColor[y] == 127)
									{
										BackgroundColor[y] = 0;
									}
									else
									{
										BackgroundColor[y]++;
									}

									for (int cellIndex = 0; cellIndex < 40; cellIndex++)
									{
										DrawCell(cellIndex,y,g);
									}

									DrawRowColorCell(y,g);
									IsDirty = true;
									break;
								case MouseButtons.Right:
									// Decrement the background color of the row
									if (BackgroundColor[y] == 0)
									{
										BackgroundColor[y] = 127;
									}
									else
									{
										BackgroundColor[y]--;
									}

									for (int cellIndex = 0; cellIndex < 40; cellIndex++)
									{
										DrawCell(cellIndex,y,g);
									}

									DrawRowColorCell(y,g);
									IsDirty = true;
									break;
							}
						}
					}

				}
			}

			g.Dispose();
		}

		private void Form1_KeyPress(object sender, KeyPressEventArgs e)
		{
			// Fire events based on the the key pressed
			switch (e.KeyChar)
			{
				case 'n':
				case 'N':
					lblNew_Click(this, EventArgs.Empty);
					break;

				case 'o':
				case 'O':
					lblOpen_Click(this, EventArgs.Empty);
					break;

				case 's':
				case 'S':
					lblSave_Click(this, EventArgs.Empty);
					break;

				case 'a':
				case 'A':
					lblOutputAsmSource_Click(this, EventArgs.Empty);
					break;
				
				case 'l':
				case 'L':
					lblChangeLabel_Click(this, EventArgs.Empty);
					break;

				case 'x':
				case 'X':
					lblExit_Click(this, EventArgs.Empty);
					break;
			}
		}

		private void Form1_Closing(object sender, CancelEventArgs e)
		{
			e.Cancel = !VerifyDirty();
			if (!e.Cancel)
			{
				Preferences.SetPreferences();
			}
		}

		private void lblNew_Click(object sender, System.EventArgs e)
		{
			if (VerifyDirty())
			{
				CreateEmptyPlayfield();
				InitializeRowColor();
				this.Refresh();
			}
		}

		private void lblOpen_Click(object sender, System.EventArgs e)
		{
			if (VerifyDirty() && OpenPlayfieldFile.ShowDialog() == DialogResult.OK)
			{
				ReadPlayfieldFile(OpenPlayfieldFile.FileName);
			}
		}

		private void lblSave_Click(object sender, System.EventArgs e)
		{
			SavePlayfieldFile.FileName = Path;
			if (SavePlayfieldFile.ShowDialog() == DialogResult.OK)
			{
				WritePlayfieldFile(SavePlayfieldFile.FileName);
			}
		}

		private void lblChangeLabel_Click(object sender, System.EventArgs e)
		{
			PlayfieldNameDialog dialog = new PlayfieldNameDialog(CurrentPlayfield.Name);
			if (dialog.ShowDialog() == DialogResult.OK)
			{
				CurrentPlayfield.Name = dialog.NewLabelName;
				lblPlayfieldLabel.Text = dialog.NewLabelName;
			}
		}

		private void lblOutputAsmSource_Click(object sender, System.EventArgs e)
		{
			if (SaveAsmSource.ShowDialog() == DialogResult.OK)
			{
				WriteAsmSourceFile(SaveAsmSource.FileName);
			}
		}

		private void lblDrawMode_Click(object sender, System.EventArgs e)
		{
			Graphics g = this.CreateGraphics();
			switch (CurrentPlayfield.Mode)
			{
				case PlayfieldModes.Nonreflected:
					bool cont = MessageBox.Show("Are you sure that you want to switch to reflected mode?  The right-" +
						"side of the playfield will be replaced.", "File Exists", MessageBoxButtons.YesNo,
						MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes;
					if (cont)
					{
						CurrentPlayfield.Mode = PlayfieldModes.Reflected;
						lblDrawMode.Text = "Reflected";
						IsDirty = true;

						for (int y = 0; y < NumRows; y++)
						{
							for (int x = 0; x < 20; x++)
							{
								CurrentPlayfield.Data[x+20,y] = CurrentPlayfield.Data[x,y];
								DrawCell(x,y,g);
							}
						}
					}					
					break;

				case PlayfieldModes.Mirrored:
					CurrentPlayfield.Mode = PlayfieldModes.Nonreflected;
					lblDrawMode.Text = "Non-Reflected";
					IsDirty = true;
					for (int y = 0; y < NumRows; y++)
					{
						for (int x = 0; x < 20; x++)
						{
							CurrentPlayfield.Data[x+20,y] = CurrentPlayfield.Data[x,y];
							DrawCell(x,y,g);
						}
					}
					break;

				case PlayfieldModes.Reflected:
					CurrentPlayfield.Mode = PlayfieldModes.Mirrored;
					lblDrawMode.Text = "Mirrored";
					IsDirty = true;

					for (int y = 0; y < NumRows; y++)
					{
						for (int x = 0; x < 20; x++)
						{
							CurrentPlayfield.Data[39-x,y] = CurrentPlayfield.Data[x,y];
							DrawCell(x,y,g);
						}
					}
					break;
			}

			g.Dispose();
			Preferences.DefaultMode = (byte)CurrentPlayfield.Mode;
		}

		private void lblOutputType_Click(object sender, System.EventArgs e)
		{
			Preferences.OutputColorData = !Preferences.OutputColorData;
			SetLabelValues();	
		}

		private void lblDataOrder_Click(object sender, System.EventArgs e)
		{			
			Preferences.ReversedOrder = !Preferences.ReversedOrder;
			SetLabelValues();
		}

		private void lblOutputDataType_Click(object sender, System.EventArgs e)
		{
			Preferences.OutputHexData = !Preferences.OutputHexData;
			SetLabelValues();
		}

		private void lblExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void lblVideoType_Click(object sender, System.EventArgs e)
		{
			Preferences.PalVideo = !Preferences.PalVideo;
			SetLabelValues();
			this.Refresh();
		}

		private void CreateEmptyPlayfield()
		{
			// Create empty Playfield
			CurrentPlayfield = new Playfield();
			CurrentPlayfield.Name = "pfdata";
			CurrentPlayfield.Data = new byte[40,NumRows];
			CurrentPlayfield.ScoreBit = false;
			CurrentPlayfield.P0Color = 0x00;
			CurrentPlayfield.P1Color = 0x00;


			for (int y = 0; y < CurrentPlayfield.Data.GetUpperBound(1); y++)
			{
				for (int x = 0; x < CurrentPlayfield.Data.GetUpperBound(0); x++)
				{
					CurrentPlayfield.Data[x,y] = 0x00;	
				}
			}
			IsDirty = false;
		}

		private void InitializePalette()
		{
			string paletteFilePath = Application.ExecutablePath.Substring(0, Application.ExecutablePath.LastIndexOf(@"\")) +
				@"\palette.dat";
			if (File.Exists(paletteFilePath))
			{
				// Read in the contents of the file
				FileStream fs = File.Open(paletteFilePath, FileMode.Open, FileAccess.Read);
				byte[] contents = new byte[768];
				fs.Read(contents, 0, 768);
				fs.Close();

				// Split the RGB Values
				byte[] r = new byte[256];
				byte[] g = new byte[256];
				byte[] b = new byte[256];
				for (int index = 0; index < 768; index++)
				{
					switch (index % 3)
					{
						case 0:
							r[index / 3] = contents[index];
							break;
						case 1:
							g[index / 3] = contents[index];
							break;
						case 2:
							b[index / 3] = contents[index];
							break;
					}
				}

				// Setup the palette array
				Palette = new Color[2,128];
				for (int index = 0; index < 256; index++)
				{
					Palette[index / 128, index % 128] = Color.FromArgb(r[index], g[index], b[index]);
				}
			}
			else
			{
				MessageBox.Show("The palette.dat file is missing!", "Critial Error", MessageBoxButtons.OK,
					MessageBoxIcon.Stop);
				this.Close();
			}

		}

		private void InitializeRowColor()
		{
			// Initialize the color arrays
			RowColor = new byte[NumRows];
			BackgroundColor = new byte[NumRows];

			// Setup the default row colors
			for (int index = 0; index <= RowColor.GetUpperBound(0); index++)
			{
				RowColor[index] = 0x01;
				BackgroundColor[index] = 0x00;
			}
		}

		private void ReadPlayfieldFile(string path)
		{
			if (File.Exists(path))
			{
				FileStream fs = File.Open(path, FileMode.Open, FileAccess.Read);
				byte[] PlayfieldName = new byte[8];
				byte[] PlayfieldData = new byte[NumRows*40];
				byte[] PlayfieldBGColor = new byte[NumRows];
				int PlayfieldMode = 0;
				float fileVersion = fs.ReadByte() + fs.ReadByte() / 100;
				
				if (fileVersion == 1.00)
				{
					fs.Read(PlayfieldName, 0, 8);
					fs.Read(PlayfieldData, 0, NumRows*40);
					fs.Read(PlayfieldBGColor, 0, NumRows);
					PlayfieldMode = fs.ReadByte();
					CurrentPlayfield.ScoreBit = fs.ReadByte() == 1;
					CurrentPlayfield.P0Color = (byte)fs.ReadByte();
					CurrentPlayfield.P1Color = (byte)fs.ReadByte();
				}

				// Load the sprite label and data
				CreateEmptyPlayfield();
				ASCIIEncoding enc = new ASCIIEncoding();
				CurrentPlayfield.Name = enc.GetString(PlayfieldName);
				for (int x = 0; x < 40; x++)
				{
					for (int y = 0; y < NumRows; y++)
					{
						byte currentData = PlayfieldData[x+y*40];
						CurrentPlayfield.Data[x,y] = currentData;
						if (currentData > 0x00 && currentData != RowColor[y])
						{
							RowColor[y] = currentData;
						}
					}
				}

				// Load the background colors
				for (int y = 0; y < NumRows; y++)
				{
					BackgroundColor[y] = PlayfieldBGColor[y];
				}

				// Load the mode from the file
				switch (PlayfieldMode)
				{
					case 1:
						CurrentPlayfield.Mode = PlayfieldModes.Reflected;
						break;
					case 2:
						CurrentPlayfield.Mode = PlayfieldModes.Mirrored;
						break;
					default:
						CurrentPlayfield.Mode = PlayfieldModes.Nonreflected;
						break;
				}
				Preferences.DefaultMode = (byte)CurrentPlayfield.Mode;
					
				fs.Close();
				Path = path;
				IsDirty = false;
				SetLabelValues();
				this.Refresh();
			}
			else
			{
				MessageBox.Show("The specified Playfield file does not exist!", "Critial Error", MessageBoxButtons.OK,
					MessageBoxIcon.Error);
			}
		}

		private void WritePlayfieldFile(string path)
		{
			if (path.Length > 0)
			{
				FileStream fs = File.Open(path, FileMode.Create, FileAccess.Write);

				// Write the version
				fs.WriteByte((byte)CurrentVersion.Major);
				fs.WriteByte((byte)CurrentVersion.Minor);
				
				// Write label as eight characters
				while (CurrentPlayfield.Name.Length < 8)
				{
					CurrentPlayfield.Name += " ";
				}

				if (CurrentPlayfield.Name.Length > 8)
				{
					CurrentPlayfield.Name = CurrentPlayfield.Name.Substring(0, 8);
				}

				// Write the playfield label to the file
				ASCIIEncoding enc = new ASCIIEncoding();
				fs.Write(enc.GetBytes(CurrentPlayfield.Name), 0, 8);

				// Write the playfield data to the file
				for (int y = 0; y < NumRows; y++)
				{
					for (int x = 0; x < 40; x++)
					{
						fs.WriteByte(CurrentPlayfield.Data[x,y]);
					}
				}

				// Write the background color info to the file
				for (int y = 0; y < NumRows; y++)
				{
					fs.WriteByte(BackgroundColor[y]);
				}

				// Write the playfield mode, score bit, P0/P1 colors to the file
				fs.WriteByte(CurrentPlayfield.Mode);
				if (CurrentPlayfield.ScoreBit)
				{
					fs.WriteByte(1);
				}
				else
				{
					fs.WriteByte(0);
				}
				fs.WriteByte(CurrentPlayfield.P0Color);
				fs.WriteByte(CurrentPlayfield.P1Color);

				fs.Close();
				Path = path;
				IsDirty = false;				
				this.Refresh();
			}
			else
			{
				MessageBox.Show("No Playfield file path specified!", "Critial Error", MessageBoxButtons.OK,
					MessageBoxIcon.Error);
			}
		}

		private void WriteAsmSourceFile(string path)
		{
			if (path.Length > 0)
			{
				bool append = false;
				bool cont = true;

				if (File.Exists(path))
				{
					bool overwrite = MessageBox.Show("Overwrite file?", "File Exists", MessageBoxButtons.YesNo,
						MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes;
					append = !overwrite;
					if (!overwrite)
					{
						cont = MessageBox.Show("Append to file?", "File Exists", MessageBoxButtons.YesNo,
							MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes;
					}
				}

				if (cont)
				{
					StreamWriter sw;
					if (append)
					{
						sw = File.AppendText(path);
					}
					else
					{
						sw = File.CreateText(path);
					}

					sw.WriteLine("; Generated by Junkosoft Playfield Editor for Windows (" + CurrentVersion.Major + "." +
						CurrentVersion.Minor + ")");
					string[,] pfdata = GetPlayfieldData();

					// Output the playfield data
					for (int x = 0; x < pfdata.GetUpperBound(0); x++)
					{
						sw.Write(CurrentPlayfield.Name.Trim());
						switch (x)
						{
							case 0:
								if (CurrentPlayfield.Mode == PlayfieldModes.Nonreflected)
								{
									sw.WriteLine("lpf0");
								}
								else
								{
									sw.WriteLine("pf0");
								}
								break;
							case 1:
								if (CurrentPlayfield.Mode == PlayfieldModes.Nonreflected)
								{
									sw.WriteLine("lpf1");
								}
								else
								{
									sw.WriteLine("pf1");
								}
								break;
							case 2:
								if (CurrentPlayfield.Mode == PlayfieldModes.Nonreflected)
								{
									sw.WriteLine("lpf2");
								}
								else
								{
									sw.WriteLine("pf2");
								}
								break;
							case 3:
								sw.WriteLine("rpf0");
								break;
							case 4:
								sw.WriteLine("rpf1");
								break;
							case 5:
								sw.WriteLine("rpf2");
								break;
						}
						
						if (Preferences.OutputHexData)
						{
							sw.Write("	.byte ");
						}

						for (int y = 0; y < NumRows; y++)
						{
							if (Preferences.OutputHexData)
							{
								sw.Write("$" + pfdata[x,y]);
								if ((y + 1) % 8 == 0 && y + 1 < NumRows)
								{
									sw.WriteLine();
									sw.Write("	.byte ");
								}
								else if (y < NumRows - 1)
								{
									sw.Write(",");
								}
							}
							else
							{
								sw.Write("	.byte %" + HexToBin(pfdata[x,y].ToCharArray()));
								if (y < NumRows - 1)
								{
									sw.WriteLine();
								}
							}
						}

						sw.WriteLine();
						sw.WriteLine();
					}

					if (Preferences.OutputColorData)
					{
						// Output the foreground colors
						sw.WriteLine("pfcolors");
						sw.Write("	.byte ");
						if (!Preferences.OutputHexData)
						{
							sw.Write("%");
						}
						
						for (int y = 0; y < NumRows; y++)
						{
							int currentColumnIndex = y;
							if (Preferences.ReversedOrder)
							{
								currentColumnIndex = (NumRows - 1) - y;
							}
							
							int currentColorValue = RowColor[currentColumnIndex] * 2;
							if (Preferences.OutputHexData)
							{
								sw.Write("$" + DecToHex(currentColorValue));
								if ((y + 1) % 8 == 0 && y + 1 < NumRows)
								{
									sw.WriteLine();
									sw.Write("	.byte ");
								}
								else if (y < NumRows - 1)
								{
									sw.Write(",");
								}
							}
							else
							{
								sw.WriteLine(DecToBin(currentColorValue));
								if (y < NumRows - 1)
								{
									sw.Write("	.byte %");
								}
							}
						}

						if (Preferences.OutputHexData)
						{
							sw.WriteLine();
						}

						// Output the background colors
						sw.WriteLine();
						sw.WriteLine("bkcolors");
						sw.Write("	.byte ");
						if (!Preferences.OutputHexData)
						{
							sw.Write("%");
						}
						
						for (int y = 0; y < NumRows; y++)
						{
							int currentColumnIndex = y;
							if (Preferences.ReversedOrder)
							{
								currentColumnIndex = (NumRows - 1) - y;
							}
		
							int currentColorValue = BackgroundColor[currentColumnIndex] * 2;
							if (Preferences.OutputHexData)
							{
								sw.Write("$" + DecToHex(currentColorValue));
								if ((y + 1) % 8 == 0 && y + 1 < NumRows)
								{
									sw.WriteLine();
									sw.Write("	.byte ");
								}
								else if (y < NumRows - 1)
								{
									sw.Write(",");
								}
							}
							else
							{
								sw.WriteLine(DecToBin(currentColorValue));
								if (y < NumRows - 1)
								{
									sw.Write("	.byte %");
								}
							}
						}

						if (Preferences.OutputHexData)
						{
							sw.WriteLine();
						}

						sw.WriteLine();
					}
		
					sw.Close();
				}
			}
			else
			{
				MessageBox.Show("No Playfield file path specified!", "Critial Error", MessageBoxButtons.OK,
					MessageBoxIcon.Error);
			}
		}

		private bool VerifyDirty()
		{
			bool cont = !IsDirty;
			if (IsDirty)
			{
				cont = MessageBox.Show("Discard changes?", "Discard Changes", MessageBoxButtons.YesNo,
					MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes;
			}

			return cont;
		}

		private void DrawCell(int x, int y, Graphics g)
		{
			SolidBrush cellBrush ;
			if (CurrentPlayfield.Data[x,y] == RowColor[y])
			{
				cellBrush = new SolidBrush(Palette[GetVideoType(), CurrentPlayfield.Data[x,y]]);				
			}
			else
			{
				cellBrush = new SolidBrush(Palette[GetVideoType(), BackgroundColor[y]]);
			}

			// Draw large cell
			g.FillRectangle(cellBrush, (x * CellWidth) + 1, (y * CellHeight) + 1, CellWidth - 2, CellHeight - 2);
			// Draw small Playfield cell
			g.FillRectangle(cellBrush, SmallGridX + (x * SmallCellWidth), SmallGridY + (y * SmallCellHeight),
				SmallCellWidth, SmallCellHeight);

		}

		private void DrawRowColorCell(int y, Graphics g)
		{
			// Draw row color
			SolidBrush rowBrush = new SolidBrush(Palette[GetVideoType(), RowColor[y]]);
			g.FillRectangle(rowBrush, GridSize + 3, (y * CellHeight) + 3, 20, 3);

			// Draw background color
			SolidBrush backgroundBrush = new SolidBrush(Palette[GetVideoType(), BackgroundColor[y]]);
			g.FillRectangle(backgroundBrush, GridSize + 28, (y * CellHeight) + 3, 20, 3);
		}

		private byte GetVideoType()
		{
			// Get current graphics type
			byte videoType = 0;
			if (Preferences.PalVideo)
			{
				videoType = 1;
			}

			return videoType;
		}

		private string BinToHex(char[] binValue)
		{
			string binString = new string(binValue);
			string hexValue = string.Empty;
			for (int count = 0; count < 2; count++)
			{
				switch (binString.Substring(count * 4, 4))
				{
					case "0000":
						hexValue += '0';
						break;
					case "0001":
						hexValue += '1';
						break;
					case "0010":
						hexValue += '2';
						break;
					case "0011":
						hexValue += '3';
						break;
					case "0100":
						hexValue += '4';
						break;
					case "0101":
						hexValue += '5';
						break;
					case "0110":
						hexValue += '6';
						break;
					case "0111":
						hexValue += '7';
						break;
					case "1000":
						hexValue += '8';
						break;
					case "1001":
						hexValue += '9';
						break;
					case "1010":
						hexValue += 'A';
						break;
					case "1011":
						hexValue += 'B';
						break;
					case "1100":
						hexValue += 'C';
						break;
					case "1101":
						hexValue += 'D';
						break;
					case "1110":
						hexValue += 'E';
						break;
					case "1111":
						hexValue += 'F';
						break;
				}
			}
			return hexValue;
		}

		private string HexToBin(char[] hexValue)
		{
			string binValue = string.Empty;

			foreach (char c in hexValue)
			{
				switch (c)
				{
					case '0': 
						binValue += "0000";
						break;
					case '1': 
						binValue += "0001";
						break;
					case '2': 
						binValue += "0010";
						break;
					case '3': 
						binValue += "0011";
						break;
					case '4': 
						binValue += "0100";
						break;
					case '5': 
						binValue += "0101";
						break;
					case '6': 
						binValue += "0110";
						break;
					case '7': 
						binValue += "0111";
						break;
					case '8': 
						binValue += "1000";
						break;
					case '9': 
						binValue += "1001";
						break;
					case 'A': 
						binValue += "1010";
						break;
					case 'B': 
						binValue += "1011";
						break;
					case 'C': 
						binValue += "1100";
						break;
					case 'D': 
						binValue += "1101";
						break;
					case 'E': 
						binValue += "1110";
						break;
					case 'F': 
						binValue += "1111";
						break;
				}
			}

			return binValue;
		}

		private string DecToHex(int i)
		{
			string decValue = string.Empty;
			for (int count = 0; count < 2; count++)
			{
				int calc = 0;
				if (count == 0)
				{
					calc = i / 16;
				}
				else
				{
					calc = i % 16;
				}

				switch (calc)
				{
					case 0:
						decValue += '0';
						break;
					case 1:
						decValue += '1';
						break;
					case 2:
						decValue += '2';
						break;
					case 3:
						decValue += '3';
						break;
					case 4:
						decValue += '4';
						break;
					case 5:
						decValue += '5';
						break;
					case 6:
						decValue += '6';
						break;
					case 7:
						decValue += '7';
						break;
					case 8:
						decValue += '8';
						break;
					case 9:
						decValue += '9';
						break;
					case 10:
						decValue += 'A';
						break;
					case 11:
						decValue += 'B';
						break;
					case 12:
						decValue += 'C';
						break;
					case 13:
						decValue += 'D';
						break;
					case 14:
						decValue += 'E';
						break;
					case 15:
						decValue += 'F';
						break;
				}
			}

			return decValue;
		}

		private string DecToBin(int i)
		{
			string binValue = string.Empty;
			for (int power = 7; power >= 0; power--)
			{
				int temp = i / Convert.ToInt32(Math.Pow(2,power));
				binValue += temp.ToString();
				i = i % Convert.ToInt32(Math.Pow(2,power));
			}

			return binValue;
		}

		private void SetLabelValues()
		{
			if (Preferences.OutputColorData)
			{
				lblOutputType.Text = "Playfield+Color Data";
			}
			else
			{
				lblOutputType.Text = "Playfield Data Only";
			}

			if (Preferences.ReversedOrder)
			{
				lblDataOrder.Text = "Reversed Order";
			}
			else
			{
				lblDataOrder.Text = "Nonreversed Order";
			}

			if (Preferences.OutputHexData)
			{
				lblOutputDataType.Text = "Hexadecimal Data";
			}
			else
			{
				lblOutputDataType.Text = "Binary Data";
			}

			if (Preferences.PalVideo)
			{
				lblVideoType.Text = "PAL";
			}
			else
			{
				lblVideoType.Text = "NTSC";
			}

			switch (Preferences.DefaultMode)
			{
				case (byte)PlayfieldModes.Nonreflected:
				lblDrawMode.Text = "Non-Reflected";
					break;
				case (byte)PlayfieldModes.Reflected:
				lblDrawMode.Text = "Reflected";
					break;
				case (byte)PlayfieldModes.Mirrored:
				lblDrawMode.Text = "Mirrored";
					break;
			}
		}

		private string[,] GetPlayfieldData()
		{
			// TODO: convert the data in CurrentPlayfield into byte array for output
			//       factor in the mode (20 bits, reflected/mirrored; 40 bits, non-reflected)
			int ByteSize = 3;
			int BitSize = 20;

			if (CurrentPlayfield.Mode == PlayfieldModes.Nonreflected)
			{
				ByteSize = 6;
				BitSize = 40;
			}
			string[,] pfdata = new string[ByteSize,NumRows];
			for (int y = 0; y < NumRows; y++)
			{
				char[] rowBinaryValue = new char[BitSize];
				int currentColumnIndex = y;
				if (Preferences.ReversedOrder)
				{
					currentColumnIndex = (NumRows - 1) - y;
				}
			
				for (int x = 0; x < BitSize; x++)
				{
					if (CurrentPlayfield.Data[x,currentColumnIndex] > 0)
					{
						rowBinaryValue[x] = '1';
					}
					else
					{
						rowBinaryValue[x] = '0';
					}
				}

				// Calculate the PF0 data for the left side of screen
				char[] pfbyte = new char[8];
				pfbyte[0] = rowBinaryValue[3];
				pfbyte[1] = rowBinaryValue[2];
				pfbyte[2] = rowBinaryValue[1];
				pfbyte[3] = rowBinaryValue[0];
				pfbyte[4] = '0';
				pfbyte[5] = '0';
				pfbyte[6] = '0';
				pfbyte[7] = '0';
				pfdata[0,y] = BinToHex(pfbyte);

				// Calculate the PF1 data for the left side of screen
				pfbyte[0] = rowBinaryValue[4];
				pfbyte[1] = rowBinaryValue[5];
				pfbyte[2] = rowBinaryValue[6];
				pfbyte[3] = rowBinaryValue[7];
				pfbyte[4] = rowBinaryValue[8];
				pfbyte[5] = rowBinaryValue[9];
				pfbyte[6] = rowBinaryValue[10];
				pfbyte[7] = rowBinaryValue[11];
				pfdata[1,y] = BinToHex(pfbyte);

				// Calculate the PF2 data for the left side of screen
				pfbyte[0] = rowBinaryValue[19];
				pfbyte[1] = rowBinaryValue[18];
				pfbyte[2] = rowBinaryValue[17];
				pfbyte[3] = rowBinaryValue[16];
				pfbyte[4] = rowBinaryValue[15];
				pfbyte[5] = rowBinaryValue[14];
				pfbyte[6] = rowBinaryValue[13];
				pfbyte[7] = rowBinaryValue[12];
				pfdata[2,y] = BinToHex(pfbyte);

				if (CurrentPlayfield.Mode == PlayfieldModes.Nonreflected)
				{
					// Calculate the PF0 data for the right side of screen
					pfbyte[0] = rowBinaryValue[23];
					pfbyte[1] = rowBinaryValue[22];
					pfbyte[2] = rowBinaryValue[21];
					pfbyte[3] = rowBinaryValue[20];
					pfbyte[4] = '0';
					pfbyte[5] = '0';
					pfbyte[6] = '0';
					pfbyte[7] = '0';
					pfdata[3,y] = BinToHex(pfbyte);

					// Calculate the PF1 data for the right side of screen
					pfbyte[0] = rowBinaryValue[24];
					pfbyte[1] = rowBinaryValue[25];
					pfbyte[2] = rowBinaryValue[26];
					pfbyte[3] = rowBinaryValue[27];
					pfbyte[4] = rowBinaryValue[28];
					pfbyte[5] = rowBinaryValue[29];
					pfbyte[6] = rowBinaryValue[30];
					pfbyte[7] = rowBinaryValue[31];
					pfdata[4,y] = BinToHex(pfbyte);

					// Calculate the PF2 data for the right side of screen
					pfbyte[0] = rowBinaryValue[39];
					pfbyte[1] = rowBinaryValue[38];
					pfbyte[2] = rowBinaryValue[37];
					pfbyte[3] = rowBinaryValue[36];
					pfbyte[4] = rowBinaryValue[35];
					pfbyte[5] = rowBinaryValue[34];
					pfbyte[6] = rowBinaryValue[33];
					pfbyte[7] = rowBinaryValue[32];
					pfdata[5,y] = BinToHex(pfbyte);
				}
			}

			return pfdata;
		}
	}

	public class PlayfieldModes
	{
		public const byte Nonreflected = 0;
		public const byte Reflected = 1;
		public const byte Mirrored = 2;
	}
}
