// Wishlist!
// implement the background color
// reimplement the fill row option?
// rotation / vertical flip / horizontal flip options
// store sprite data in database as a collection of sprites
// toggle from sprite to sprite within application

using System;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace SpriteEditor
{
	public struct Sprite
	{
		public string Name;
		public byte[,] Data;
	}

	/// <summary>
	/// Junkosoft Sprite Editor Main Form
	/// </summary>
	public class SpriteEditorForm : System.Windows.Forms.Form
	{
		private const byte CellSize = 60;
		private const int GridFullLength = 495;
		private const int GridSize = 480;
		private const int SmallGridX = 550;
		private const int SmallGridY = 320;
		private const int SmallCellSize = 4;

		private string Path;
		private bool IsDirty;
		private Sprite CurrentSprite;
		private Color[,] Palette;
		private byte[] RowColor;

		private System.Windows.Forms.Label lblVideoType;
		private System.Windows.Forms.Label lblNew;
		private System.Windows.Forms.Label lblOpen;
		private System.Windows.Forms.Label lblSave;
		private System.Windows.Forms.Label lblChangeLabel;
		private System.Windows.Forms.Label lblOutputAsmSource;
		private System.Windows.Forms.Label lblFillSprite;
		private System.Windows.Forms.Label lblOutputType;
		private System.Windows.Forms.Label lblDataOrder;
		private System.Windows.Forms.Label lblOutputDataType;
		private System.Windows.Forms.Label lblSpriteLabel;
		private System.Windows.Forms.Label lblExit;
		private System.Windows.Forms.Label lblTitle;
		private System.Windows.Forms.SaveFileDialog SaveSpriteFile;
		private System.Windows.Forms.SaveFileDialog SaveAsmSource;
		private System.Windows.Forms.OpenFileDialog OpenSpriteFile;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SpriteEditorForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			Preferences.GetPreferences();
			SetLabelValues();
			CreateEmptySprite();
			InitializePalette();
			InitializeRowColor();
		}

		public SpriteEditorForm(string path) : this()
		{
			//
			// Required for Windows Form Designer support
			//
			ReadSpriteFile(path);
			Path = path;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblVideoType = new System.Windows.Forms.Label();
			this.lblNew = new System.Windows.Forms.Label();
			this.lblOpen = new System.Windows.Forms.Label();
			this.lblSave = new System.Windows.Forms.Label();
			this.lblChangeLabel = new System.Windows.Forms.Label();
			this.lblOutputAsmSource = new System.Windows.Forms.Label();
			this.lblFillSprite = new System.Windows.Forms.Label();
			this.lblOutputType = new System.Windows.Forms.Label();
			this.lblDataOrder = new System.Windows.Forms.Label();
			this.lblOutputDataType = new System.Windows.Forms.Label();
			this.lblSpriteLabel = new System.Windows.Forms.Label();
			this.lblExit = new System.Windows.Forms.Label();
			this.lblTitle = new System.Windows.Forms.Label();
			this.SaveSpriteFile = new System.Windows.Forms.SaveFileDialog();
			this.SaveAsmSource = new System.Windows.Forms.SaveFileDialog();
			this.OpenSpriteFile = new System.Windows.Forms.OpenFileDialog();
			this.SuspendLayout();
			// 
			// lblVideoType
			// 
			this.lblVideoType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblVideoType.Location = new System.Drawing.Point(624, 312);
			this.lblVideoType.Name = "lblVideoType";
			this.lblVideoType.Size = new System.Drawing.Size(12, 56);
			this.lblVideoType.TabIndex = 10;
			this.lblVideoType.Text = "NTSC";
			this.lblVideoType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblVideoType.Click += new System.EventHandler(this.lblVideoType_Click);
			// 
			// lblNew
			// 
			this.lblNew.BackColor = System.Drawing.Color.Transparent;
			this.lblNew.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblNew.Location = new System.Drawing.Point(496, 1);
			this.lblNew.Name = "lblNew";
			this.lblNew.Size = new System.Drawing.Size(144, 25);
			this.lblNew.TabIndex = 0;
			this.lblNew.Text = "New";
			this.lblNew.Click += new System.EventHandler(this.lblNew_Click);
			// 
			// lblOpen
			// 
			this.lblOpen.BackColor = System.Drawing.Color.Transparent;
			this.lblOpen.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblOpen.Location = new System.Drawing.Point(496, 31);
			this.lblOpen.Name = "lblOpen";
			this.lblOpen.Size = new System.Drawing.Size(144, 25);
			this.lblOpen.TabIndex = 1;
			this.lblOpen.Text = "Open";
			this.lblOpen.Click += new System.EventHandler(this.lblOpen_Click);
			// 
			// lblSave
			// 
			this.lblSave.BackColor = System.Drawing.Color.Transparent;
			this.lblSave.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblSave.Location = new System.Drawing.Point(496, 61);
			this.lblSave.Name = "lblSave";
			this.lblSave.Size = new System.Drawing.Size(144, 25);
			this.lblSave.TabIndex = 2;
			this.lblSave.Text = "Save";
			this.lblSave.Click += new System.EventHandler(this.lblSave_Click);
			// 
			// lblChangeLabel
			// 
			this.lblChangeLabel.BackColor = System.Drawing.Color.Transparent;
			this.lblChangeLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblChangeLabel.Location = new System.Drawing.Point(496, 91);
			this.lblChangeLabel.Name = "lblChangeLabel";
			this.lblChangeLabel.Size = new System.Drawing.Size(144, 25);
			this.lblChangeLabel.TabIndex = 3;
			this.lblChangeLabel.Text = "Change Label";
			this.lblChangeLabel.Click += new System.EventHandler(this.lblChangeLabel_Click);
			// 
			// lblOutputAsmSource
			// 
			this.lblOutputAsmSource.BackColor = System.Drawing.Color.Transparent;
			this.lblOutputAsmSource.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblOutputAsmSource.Location = new System.Drawing.Point(496, 121);
			this.lblOutputAsmSource.Name = "lblOutputAsmSource";
			this.lblOutputAsmSource.Size = new System.Drawing.Size(144, 25);
			this.lblOutputAsmSource.TabIndex = 4;
			this.lblOutputAsmSource.Text = "Output Asm Source";
			this.lblOutputAsmSource.Click += new System.EventHandler(this.lblOutputAsmSource_Click);
			// 
			// lblFillSprite
			// 
			this.lblFillSprite.BackColor = System.Drawing.Color.Transparent;
			this.lblFillSprite.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblFillSprite.Location = new System.Drawing.Point(496, 151);
			this.lblFillSprite.Name = "lblFillSprite";
			this.lblFillSprite.Size = new System.Drawing.Size(144, 25);
			this.lblFillSprite.TabIndex = 5;
			this.lblFillSprite.Text = "Fill Whole Sprite";
			this.lblFillSprite.Click += new System.EventHandler(this.lblFillSprite_Click);
			// 
			// lblOutputType
			// 
			this.lblOutputType.BackColor = System.Drawing.Color.Transparent;
			this.lblOutputType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblOutputType.Location = new System.Drawing.Point(496, 181);
			this.lblOutputType.Name = "lblOutputType";
			this.lblOutputType.Size = new System.Drawing.Size(144, 25);
			this.lblOutputType.TabIndex = 6;
			this.lblOutputType.Text = "Sprite Data Only";
			this.lblOutputType.Click += new System.EventHandler(this.lblOutputType_Click);
			// 
			// lblDataOrder
			// 
			this.lblDataOrder.BackColor = System.Drawing.Color.Transparent;
			this.lblDataOrder.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblDataOrder.Location = new System.Drawing.Point(496, 211);
			this.lblDataOrder.Name = "lblDataOrder";
			this.lblDataOrder.Size = new System.Drawing.Size(144, 25);
			this.lblDataOrder.TabIndex = 7;
			this.lblDataOrder.Text = "Nonreversed Order";
			this.lblDataOrder.Click += new System.EventHandler(this.lblDataOrder_Click);
			// 
			// lblOutputDataType
			// 
			this.lblOutputDataType.BackColor = System.Drawing.Color.Transparent;
			this.lblOutputDataType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblOutputDataType.Location = new System.Drawing.Point(496, 241);
			this.lblOutputDataType.Name = "lblOutputDataType";
			this.lblOutputDataType.Size = new System.Drawing.Size(144, 25);
			this.lblOutputDataType.TabIndex = 8;
			this.lblOutputDataType.Text = "Binary Data";
			this.lblOutputDataType.Click += new System.EventHandler(this.lblOutputDataType_Click);
			// 
			// lblSpriteLabel
			// 
			this.lblSpriteLabel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblSpriteLabel.Location = new System.Drawing.Point(544, 364);
			this.lblSpriteLabel.Name = "lblSpriteLabel";
			this.lblSpriteLabel.Size = new System.Drawing.Size(64, 16);
			this.lblSpriteLabel.TabIndex = 11;
			// 
			// lblExit
			// 
			this.lblExit.BackColor = System.Drawing.Color.Transparent;
			this.lblExit.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblExit.Location = new System.Drawing.Point(496, 271);
			this.lblExit.Name = "lblExit";
			this.lblExit.Size = new System.Drawing.Size(144, 25);
			this.lblExit.TabIndex = 9;
			this.lblExit.Text = "Exit";
			this.lblExit.Click += new System.EventHandler(this.lblExit_Click);
			// 
			// lblTitle
			// 
			this.lblTitle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTitle.Location = new System.Drawing.Point(528, 448);
			this.lblTitle.Name = "lblTitle";
			this.lblTitle.Size = new System.Drawing.Size(104, 32);
			this.lblTitle.TabIndex = 12;
			this.lblTitle.Text = "Junkosoft Sprite Editor";
			this.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// SaveSpriteFile
			// 
			this.SaveSpriteFile.DefaultExt = "spr";
			this.SaveSpriteFile.Filter = "Sprite Files (*.spr)|*.spr|All Files (*.*)|*.*";
			this.SaveSpriteFile.Title = "Save Sprite Data As";
			// 
			// SaveAsmSource
			// 
			this.SaveAsmSource.DefaultExt = "s";
			this.SaveAsmSource.Filter = "Assembly Source (*.s)|*.s|All Files (*.*)|*.*";
			this.SaveAsmSource.OverwritePrompt = false;
			this.SaveAsmSource.Title = "Save Assembly Source As";
			// 
			// OpenSpriteFile
			// 
			this.OpenSpriteFile.DefaultExt = "spr";
			this.OpenSpriteFile.Filter = "Sprite Files (*.spr)|*.spr|All Files (*.*)|*.*";
			this.OpenSpriteFile.Title = "Open Sprite Data";
			// 
			// SpriteEditorForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(7, 14);
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(642, 481);
			this.Controls.Add(this.lblTitle);
			this.Controls.Add(this.lblExit);
			this.Controls.Add(this.lblSpriteLabel);
			this.Controls.Add(this.lblOutputDataType);
			this.Controls.Add(this.lblDataOrder);
			this.Controls.Add(this.lblOutputType);
			this.Controls.Add(this.lblFillSprite);
			this.Controls.Add(this.lblOutputAsmSource);
			this.Controls.Add(this.lblChangeLabel);
			this.Controls.Add(this.lblSave);
			this.Controls.Add(this.lblOpen);
			this.Controls.Add(this.lblNew);
			this.Controls.Add(this.lblVideoType);
			this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.ForeColor = System.Drawing.Color.White;
			this.MaximizeBox = false;
			this.Name = "SpriteEditorForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Junkosoft Sprite Editor for Atari 2600";
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMoveOrMouseDown);
			this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMoveOrMouseDown);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) 
		{
			if (args.Length == 0)
			{
				Application.Run(new SpriteEditorForm());
			}
			else
			{
				Application.Run(new SpriteEditorForm(args[0]));
			}
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{

		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics current = this.CreateGraphics();
			Pen drawingPen = new Pen(Color.White, 1);

			for (int x = 0; x <= 8 ; x++)
			{				 
				Point start = new Point(x * CellSize, 0);
				Point end = new Point(x * CellSize, GridFullLength);
				current.DrawLine(drawingPen, start, end);
			}

			for (int y = 0; y <= 8; y++)
			{
				Point start = new Point(0, y * CellSize);
				Point end = new Point(GridSize, y * CellSize);
				current.DrawLine(drawingPen, start, end);
			}

			for (int y = 0; y <= 8; y++)
			{
				Point start = new Point(8 * CellSize, y * CellSize);
				Point end = new Point(GridFullLength, y * CellSize);
				current.DrawLine(drawingPen, start, end);
			}

			Point p1 = new Point(GridFullLength, 0);
			Point p2 = new Point(GridFullLength, GridSize);
			current.DrawLine(drawingPen, p1, p2);

			p1 = new Point(650, 0);
			p2 = new Point(650, 300);
			current.DrawLine(drawingPen, p1, p2);

			for (int y = 0; y <= 10; y++)
			{
				Point start = new Point(GridFullLength, y * CellSize / 2);
				Point end = new Point(650, y * CellSize / 2);
				current.DrawLine(drawingPen, start, end);
			}

			// Draw the sprite data
			for (int y = 0; y < 8; y++)
			{
				// Draw sprite data row
				for (int x = 0; x < 8; x++)
				{
					DrawCell(x,y,current);
				}
				DrawRowColorCell(y,current);
			}

			drawingPen.Dispose();
			current.Dispose();
			lblSpriteLabel.Text = CurrentSprite.Name;
		}

		private void Form1_MouseMoveOrMouseDown(object sender, MouseEventArgs e)
		{
			Graphics g = this.CreateGraphics();

			for (int y = 0; y < 8; y++)
			{
				for (int x = 0; x < 9; x++)
				{
					if (x < 8)
					{
						// Check rows in cell
						if (e.X > x * CellSize && e.X < (x+1) * CellSize && e.Y > y * CellSize &&
							e.Y < (y+1) * CellSize)
						{
							if (e.Button == MouseButtons.Left)
							{
								CurrentSprite.Data[x,y] = RowColor[y];
								DrawCell(x,y,g);
								IsDirty = true;
							}
							else if (e.Button == MouseButtons.Right)
							{
								CurrentSprite.Data[x,y] = 0x00;
								DrawCell(x,y,g);
								IsDirty = true;
							}
						}
					}
					else
					{
						// Check row color
						if (e.X > GridSize && e.X < GridFullLength && e.Y > y * CellSize &&
							e.Y < (y+1) * CellSize)
						{
							switch (e.Button)
							{
								case MouseButtons.Left:
									// Increment the color of the row
									RowColor[y]++;
									if (RowColor[y] > 127)
									{
										RowColor[y] = 1;
									}

									for (int cellIndex = 0; cellIndex < 8; cellIndex++)
									{
										if (CurrentSprite.Data[cellIndex,y] > 0x00)
										{
											CurrentSprite.Data[cellIndex,y] = RowColor[y];
										}
										DrawCell(cellIndex,y,g);
									}

									DrawRowColorCell(y,g);
									IsDirty = true;
									break;
								case MouseButtons.Right:
									// Decrement the color of the row
									RowColor[y]--;
									if (RowColor[y] < 1)
									{
										RowColor[y] = 127;
									}

									for (int cellIndex = 0; cellIndex < 8; cellIndex++)
									{
										if (CurrentSprite.Data[cellIndex,y] > 0x00)
										{
											CurrentSprite.Data[cellIndex,y] = RowColor[y];
										}
										DrawCell(cellIndex,y,g);
									}

									DrawRowColorCell(y,g);
									IsDirty = true;

// Note: preserving the code to perform fill row function
//									// Fill or clear the row
//									bool isFull = true;
//									for (int cellIndex = 0; cellIndex < 8; cellIndex++)
//									{
//										if (CurrentSprite.Data[cellIndex,y] > 0x00)
//										{
//											isFull = false;
//											break;
//										}
//									}
//
//									for (int cellIndex = 0; cellIndex < 8; cellIndex++)
//									{
//										if (isFull)
//										{
//											// Set the color to the row color
//											CurrentSprite.Data[cellIndex,y] = RowColor[y];
//										}
//										else
//										{
//											// Set the color to 0
//											CurrentSprite.Data[cellIndex,y] = 0x00;										
//										}
//										DrawCell(cellIndex,y,g);
//									}
									break;
							}
							
						}

					}
				}
			}

			g.Dispose();
		}

		private void Form1_KeyPress(object sender, KeyPressEventArgs e)
		{
			// Fire events based on the the key pressed
			switch (e.KeyChar)
			{
				case 'n':
				case 'N':
					lblNew_Click(this, EventArgs.Empty);
					break;

				case 'o':
				case 'O':
					lblOpen_Click(this, EventArgs.Empty);
					break;

				case 's':
				case 'S':
					lblSave_Click(this, EventArgs.Empty);
					break;

				case 'a':
				case 'A':
					lblOutputAsmSource_Click(this, EventArgs.Empty);
					break;
				
				case 'l':
				case 'L':
					lblChangeLabel_Click(this, EventArgs.Empty);
					break;

				case 'x':
				case 'X':
					lblExit_Click(this, EventArgs.Empty);
					break;
			}
		}

		private void Form1_Closing(object sender, CancelEventArgs e)
		{
			e.Cancel = !VerifyDirty();
			if (!e.Cancel)
			{
				Preferences.SetPreferences();
			}
		}

		private void lblNew_Click(object sender, System.EventArgs e)
		{
			if (VerifyDirty())
			{
				CreateEmptySprite();
				InitializeRowColor();
				this.Refresh();
			}
		}

		private void lblOpen_Click(object sender, System.EventArgs e)
		{
			if (VerifyDirty() && OpenSpriteFile.ShowDialog() == DialogResult.OK)
			{
				ReadSpriteFile(OpenSpriteFile.FileName);
			}
		}

		private void lblSave_Click(object sender, System.EventArgs e)
		{
			SaveSpriteFile.FileName = Path;
			if (SaveSpriteFile.ShowDialog() == DialogResult.OK)
			{
				WriteSpriteFile(SaveSpriteFile.FileName);
			}
		}

		private void lblChangeLabel_Click(object sender, System.EventArgs e)
		{
			SpriteNameDialog dialog = new SpriteNameDialog(CurrentSprite.Name);
			if (dialog.ShowDialog() == DialogResult.OK)
			{
				CurrentSprite.Name = dialog.NewLabelName;
				lblSpriteLabel.Text = dialog.NewLabelName;
			}
		}

		private void lblOutputAsmSource_Click(object sender, System.EventArgs e)
		{
			if (SaveAsmSource.ShowDialog() == DialogResult.OK)
			{
				WriteAsmSourceFile(SaveAsmSource.FileName);
			}
		}

		private void lblFillSprite_Click(object sender, System.EventArgs e)
		{
			Graphics g = this.CreateGraphics();
			for (int y = 0; y < 8; y++)
			{
				for (int x = 0; x < 8; x++)
				{
					CurrentSprite.Data[x,y] = RowColor[y];
					DrawCell(x,y,g);
				}
			}
			g.Dispose();

			IsDirty = true;
		}

		private void lblOutputType_Click(object sender, System.EventArgs e)
		{
			Preferences.OutputColorData = !Preferences.OutputColorData;
			SetLabelValues();	
		}

		private void lblDataOrder_Click(object sender, System.EventArgs e)
		{
			Preferences.ReversedOrder = !Preferences.ReversedOrder;
			SetLabelValues();
		}

		private void lblOutputDataType_Click(object sender, System.EventArgs e)
		{
			Preferences.OutputHexData = !Preferences.OutputHexData;
			SetLabelValues();
		}

		private void lblExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void lblVideoType_Click(object sender, System.EventArgs e)
		{
			Preferences.PalVideo = !Preferences.PalVideo;
			SetLabelValues();
			this.Refresh();
		}

		private void CreateEmptySprite()
		{
			// Create empty sprite
			CurrentSprite = new Sprite();
			CurrentSprite.Name = "sprdata";
			CurrentSprite.Data = new byte[8,8];

			for (int x = 0; x < CurrentSprite.Data.GetUpperBound(0); x++)
			{
				for (int y = 0; y < CurrentSprite.Data.GetUpperBound(1); y++)
				{
					CurrentSprite.Data[x,y] = 0x00;
				}
			}
			IsDirty = false;
		}

		private void InitializePalette()
		{
			string paletteFilePath = Application.ExecutablePath.Substring(0, Application.ExecutablePath.LastIndexOf(@"\")) +
				@"\palette.dat";
			if (File.Exists(paletteFilePath))
			{
				// Read in the contents of the file
				FileStream fs = File.Open(paletteFilePath, FileMode.Open, FileAccess.Read);
				byte[] contents = new byte[768];
				fs.Read(contents, 0, 768);
				fs.Close();

				// Split the RGB Values
				byte[] r = new byte[256];
				byte[] g = new byte[256];
				byte[] b = new byte[256];
				for (int index = 0; index < 768; index++)
				{
					switch (index % 3)
					{
						case 0:
							r[index / 3] = contents[index];
							break;
						case 1:
							g[index / 3] = contents[index];
							break;
						case 2:
							b[index / 3] = contents[index];
							break;
					}
				}

				// Setup the palette array
				Palette = new Color[2,128];
				for (int index = 0; index < 256; index++)
				{
					Palette[index / 128, index % 128] = Color.FromArgb(r[index], g[index], b[index]);
				}
			}
			else
			{
				MessageBox.Show("The palette.dat file is missing!", "Critial Error", MessageBoxButtons.OK,
					MessageBoxIcon.Stop);
				this.Close();
			}

		}

		private void InitializeRowColor()
		{
			// Setup the default row colors
			RowColor = new byte[8];
			for (int index = 0; index < 8; index++)
			{
				RowColor[index] = 0x01;
			}
		}

		private void ReadSpriteFile(string path)
		{
			if (File.Exists(path))
			{
				FileStream fs = File.Open(path, FileMode.Open, FileAccess.Read);
				byte[] spriteName = new byte[8];
				byte[] spriteData = new byte[64];
				fs.ReadByte();
				fs.Read(spriteName, 0, 8);
				fs.Read(spriteData, 0, 64);
				
				CreateEmptySprite();
				ASCIIEncoding enc = new ASCIIEncoding();
				CurrentSprite.Name = enc.GetString(spriteName);
				for (int x = 0; x < 8; x++)
				{
					for (int y = 0; y < 8; y++)
					{
						byte currentData = spriteData[x*8+y];
						CurrentSprite.Data[x,y] = currentData;
						if (currentData > 0x00 && currentData != RowColor[y])
						{
							RowColor[y] = currentData;
						}
					}
				}
				
				fs.Close();
				Path = path;
				IsDirty = false;
				this.Refresh();
			}
			else
			{
				MessageBox.Show("The specified sprite file does not exist!", "Critial Error", MessageBoxButtons.OK,
					MessageBoxIcon.Error);
			}
		}

		private void WriteSpriteFile(string path)
		{
			if (path.Length > 0)
			{
				FileStream fs = File.Open(path, FileMode.Create, FileAccess.Write);
				fs.WriteByte(0x08);
				while (CurrentSprite.Name.Length < 8)
				{
					CurrentSprite.Name += " ";
				}

				if (CurrentSprite.Name.Length > 8)
				{
					CurrentSprite.Name = CurrentSprite.Name.Substring(0, 8);
				}

				ASCIIEncoding enc = new ASCIIEncoding();		
				fs.Write(enc.GetBytes(CurrentSprite.Name), 0, 8);
				for (int x = 0; x < 8; x++)
				{
					for (int y = 0; y < 8; y++)
					{
						fs.WriteByte(CurrentSprite.Data[x,y]);
					}
				}

				fs.Close();
				Path = path;
				IsDirty = false;				
				this.Refresh();
			}
			else
			{
				MessageBox.Show("No sprite file path specified!", "Critial Error", MessageBoxButtons.OK,
					MessageBoxIcon.Error);
			}
		}

		private void WriteAsmSourceFile(string path)
		{
			if (path.Length > 0)
			{
				bool append = false;
				bool cont = true;

				if (File.Exists(path))
				{
					bool overwrite = MessageBox.Show("Overwrite file?", "File Exists", MessageBoxButtons.YesNo,
						MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes;
					append = !overwrite;
					if (!overwrite)
					{
						cont = MessageBox.Show("Append to file?", "File Exists", MessageBoxButtons.YesNo,
							MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes;
					}
				}

				if (cont)
				{
					bool asProgram = MessageBox.Show("Output Stub Program?", "Options", MessageBoxButtons.YesNo,
						MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes;

					StreamWriter sw;
					if (append)
					{
						sw = File.AppendText(path);
					}
					else
					{
						sw = File.CreateText(path);
					}

					Version currentVersion = new Version(Application.ProductVersion);

					if (asProgram)
					{
						sw.WriteLine("; Sprite Demo / Test");
						sw.WriteLine("; Charles Wieland, 8/26/1998");
						sw.WriteLine("; junkosoft.org (http://www.rollanet.org/~junko/)");
						sw.WriteLine("; Generated by JunkoSoft Sprite Editor for Windows (" + currentVersion.Major + "." +
							currentVersion.Minor + "), " + DateTime.Now.Month.ToString() + "/" +
							DateTime.Now.Month.ToString() + "/" + DateTime.Now.Year.ToString());
						sw.WriteLine();
						sw.WriteLine("	processor 6502");
						sw.WriteLine("	ORG $F000");
						sw.WriteLine();
						sw.WriteLine("VSYNC  = $00");
						sw.WriteLine("VBLANK = $01");
						sw.WriteLine("WSYNC  = $02");
						sw.WriteLine("RSYNC  = $03");
						sw.WriteLine("NUSIZ0 = $04");
						sw.WriteLine("NUSIZ1 = $05");
						sw.WriteLine("COLUP0 = $06");
						sw.WriteLine("COLUP1 = $07");
						sw.WriteLine("COLUPF = $08");
						sw.WriteLine("COLUBK = $09");
						sw.WriteLine("CTRLPF = $0A");
						sw.WriteLine("REFP0  = $0B");
						sw.WriteLine("REFP1  = $0C");
						sw.WriteLine("PF0    = $0D");
						sw.WriteLine("PF1    = $0E");
						sw.WriteLine("PF2    = $0F");
						sw.WriteLine("RESP0  = $10");
						sw.WriteLine("POSH2  = $11");
						sw.WriteLine("RESP1  = $11");
						sw.WriteLine("RESM0  = $12");
						sw.WriteLine("RESM1  = $13");
						sw.WriteLine("RESBL  = $14");
						sw.WriteLine("AUDC0  = $15");
						sw.WriteLine("AUDC1  = $16");
						sw.WriteLine("AUDF0  = $17");
						sw.WriteLine("AUDF1  = $18");
						sw.WriteLine("AUDV0  = $19");
						sw.WriteLine("AUDV1  = $1A");
						sw.WriteLine("GRP0   = $1B");
						sw.WriteLine("GRP1   = $1C");
						sw.WriteLine("ENAM0  = $1D");
						sw.WriteLine("ENAM1  = $1E");
						sw.WriteLine("ENABL  = $1F");
						sw.WriteLine("HMP0   = $20");
						sw.WriteLine("HMP1   = $21");
						sw.WriteLine("HMM0   = $22");
						sw.WriteLine("HMM1   = $23");
						sw.WriteLine("HMBL   = $24");
						sw.WriteLine("VDELP0 = $25");
						sw.WriteLine("VDELP1 = $26");
						sw.WriteLine("VDELBL = $27");
						sw.WriteLine("RESMP0 = $28");
						sw.WriteLine("RESMP1 = $29");
						sw.WriteLine("HMOVE  = $2A");
						sw.WriteLine("HMCLR  = $2B");
						sw.WriteLine("CXCLR  = $2C");
						sw.WriteLine();
						sw.WriteLine("CXM0P  = $30");
						sw.WriteLine("CXM1P  = $31");
						sw.WriteLine("CXP0FB = $32");
						sw.WriteLine("CXP1FB = $33");
						sw.WriteLine("CXM0FB = $34");
						sw.WriteLine("CXM1FB = $35");
						sw.WriteLine("CXBLPF = $36");
						sw.WriteLine("CXPPMM = $37");
						sw.WriteLine("INPT0  = $38");
						sw.WriteLine("INPT1  = $39");
						sw.WriteLine("INPT2  = $3A");
						sw.WriteLine("INPT3  = $3B");
						sw.WriteLine("INPT4  = $3C");
						sw.WriteLine("INPT5  = $3D");
						sw.WriteLine();
						sw.WriteLine("SWCHA  = $280");
						sw.WriteLine("SWACNT = $281");
						sw.WriteLine("SWCHB  = $282");
						sw.WriteLine("SWBCNT = $283");
						sw.WriteLine("INTIM  = $284");
						sw.WriteLine("TIM1T  = $294");
						sw.WriteLine("TIM8T  = $295");
						sw.WriteLine("TIM64T = $296");
						sw.WriteLine("T1024T = $297");
						sw.WriteLine();
						sw.WriteLine("TOPPOS	= $80 ; Number of lines at top");
						sw.WriteLine("BOTPOS	= $81 ; Number of lines at bottom");
						sw.WriteLine("SPRSIZE	= $82 ; Size of sprite in scanlines");
						if (!Preferences.OutputColorData)
						{
							sw.WriteLine("SPRCOLOR	= $83 ; Color of sprite");
						}
						sw.WriteLine();
						sw.WriteLine("; Main Program and Initialization");
						sw.WriteLine();
						sw.WriteLine("Start   SEI");
						sw.WriteLine("	CLD");
						sw.WriteLine("	LDX #$FF");
						sw.WriteLine("	TXS");
						sw.WriteLine("	LDA #$00");
						sw.WriteLine();
						sw.WriteLine("clrstk  STA $00,X");
						sw.WriteLine("	DEX");
						sw.WriteLine("	BNE clrstk");
						sw.WriteLine("	LDA #$08");
						sw.WriteLine("	STA SPRSIZE     ; Size of sprite (8 scanlines)");
						sw.WriteLine("	LDA #$5C        ; Initial Sprite location");
						sw.WriteLine("	STA TOPPOS");
						sw.WriteLine("	STA BOTPOS");
						sw.WriteLine("	LDA #$00");
						sw.WriteLine("	STA COLUPF      ; Black playfield color");
						sw.WriteLine();
						sw.WriteLine("	LDX #$5C");
						if (!Preferences.OutputColorData)
						{
							sw.WriteLine("	LDX #$0F");
							sw.WriteLine("	STX SPRCOLOR	; White sprite color");
						}
						sw.WriteLine("topfrm  STA WSYNC");
						sw.WriteLine("	DEX");
						sw.WriteLine("	BNE topfrm");
						sw.WriteLine("	LDX #$90");
						sw.WriteLine("delay   DEX");
						sw.WriteLine("	BNE delay");
						sw.WriteLine("	NOP");
						sw.WriteLine("	STA RESP0");
						sw.WriteLine("	STA WSYNC");
						sw.WriteLine("	LDX #$63");
						sw.WriteLine("btmfrm  STA WSYNC");
						sw.WriteLine("	DEX");
						sw.WriteLine("	BNE btmfrm");
						sw.WriteLine();
						sw.WriteLine("; Vertical Blank Handler");
						sw.WriteLine();
						sw.WriteLine("vblank  LDA #$02");
						sw.WriteLine("	STA WSYNC");
						sw.WriteLine("	STA WSYNC");
						sw.WriteLine("	STA WSYNC");
						sw.WriteLine("	STA VSYNC");
						sw.WriteLine("	STA WSYNC");
						sw.WriteLine("	STA WSYNC");
						sw.WriteLine("	STA HMOVE");
						sw.WriteLine("	LDA #$2C");
						sw.WriteLine("	STA TIM64T");
						sw.WriteLine("	LDA #$00");
						sw.WriteLine("	STA CXCLR       ");
						sw.WriteLine("	STA WSYNC");
						sw.WriteLine("	STA VSYNC");
						sw.WriteLine();
						sw.WriteLine("; Screen Draw routine");
						sw.WriteLine();
						sw.WriteLine("draw    LDA INTIM");
						sw.WriteLine("	BNE draw");
						sw.WriteLine("	STA WSYNC");
						sw.WriteLine("	STA VBLANK");
						sw.WriteLine("	LDX TOPPOS");
						if (!Preferences.OutputColorData)
						{
							sw.WriteLine("	LDA SPRCOLOR");
							sw.WriteLine("	STA COLUP0");
						}
						sw.WriteLine("drawtop STA WSYNC");
						sw.WriteLine("	DEX");
						sw.WriteLine("	BNE drawtop");
						if (Preferences.ReversedOrder)
						{
							sw.WriteLine("	LDX SPRSIZE");
							sw.WriteLine("drawspr DEX");
						}
						else
						{
							sw.WriteLine("	LDX #$00");
							sw.WriteLine("drawspr");
						}
						sw.WriteLine("	LDA " + CurrentSprite.Name + ",X");
						sw.WriteLine("	STA GRP0");
						if (Preferences.OutputColorData)
						{
							sw.WriteLine("	LDA colors,X");
							sw.WriteLine("	STA COLUP0");
						}
						sw.WriteLine("	STA WSYNC");
						if (Preferences.ReversedOrder)
						{
							sw.WriteLine("	TXA");
						}
						else
						{
							sw.WriteLine("	INX");
							sw.WriteLine("	CPX SPRSIZE");
						}
						sw.WriteLine("	BNE drawspr");
						if (!Preferences.ReversedOrder)
						{
							sw.WriteLine("	LDX #$00");
						}
						sw.WriteLine("	STX GRP0");
						sw.WriteLine("	LDX BOTPOS");
						sw.WriteLine("drawbot STA WSYNC");
						sw.WriteLine("	DEX");
						sw.WriteLine("	BNE drawbot");
						sw.WriteLine();
						if (!Preferences.OutputColorData)
						{
							sw.WriteLine("	LDA INPT4");
							sw.WriteLine("	BPL inccol");
							sw.WriteLine("	JMP oscan");
							sw.WriteLine();
							sw.WriteLine("inccol	INC SPRCOLOR");
							sw.WriteLine();
						}
						sw.WriteLine("; Overscan and Joystick routine");
						sw.WriteLine();
						sw.WriteLine("oscan   LDA SWCHA");
						sw.WriteLine("	CMP #$BF");
						sw.WriteLine("	BEQ left");
						sw.WriteLine("	CMP #$7F");
						sw.WriteLine("	BEQ right");
						sw.WriteLine();
						sw.WriteLine("	LDA #$00");
						sw.WriteLine("	STA HMP0");
						sw.WriteLine();
						sw.WriteLine("	LDA SWCHA");
						sw.WriteLine("	CMP #$EF");
						sw.WriteLine("	BEQ up");
						sw.WriteLine("	CMP #$DF");
						sw.WriteLine("	BEQ down");
						sw.WriteLine("	JMP over");
						sw.WriteLine();
						sw.WriteLine("up      LDA TOPPOS");
						sw.WriteLine("	CMP #$01");
						sw.WriteLine("	BEQ over");
						sw.WriteLine("	DEC TOPPOS");
						sw.WriteLine("	INC BOTPOS");
						sw.WriteLine("	JMP over");
						sw.WriteLine();
						sw.WriteLine("down    LDA BOTPOS");
						sw.WriteLine("	CMP #$01");
						sw.WriteLine("	BEQ over");
						sw.WriteLine("	DEC BOTPOS");
						sw.WriteLine("	INC TOPPOS");
						sw.WriteLine("	JMP over");
						sw.WriteLine();
						sw.WriteLine("left    LDA #$10");
						sw.WriteLine("	STA HMP0");
						sw.WriteLine("	JMP over");
						sw.WriteLine();
						sw.WriteLine("right   LDA #$F0");
						sw.WriteLine("	STA HMP0");
						sw.WriteLine();
						sw.WriteLine("over    LDX #$1E");
						sw.WriteLine("doscan  STA WSYNC");
						sw.WriteLine("	DEX");
						sw.WriteLine("	BNE doscan");
						sw.WriteLine("	JMP vblank");
						sw.WriteLine();
					}
					sw.WriteLine("; Generated by Junkosoft Sprite Editor for Windows (" + currentVersion.Major + "." +
						currentVersion.Minor + ")");
					sw.Write(CurrentSprite.Name);
					sw.Write("	.byte ");
					if (Preferences.OutputHexData)
					{
						sw.Write("$");
					}
					else
					{
						sw.Write("%");
					}
					for (int y = 0; y < 8; y++)
					{
						char[] rowBinaryValue = new char[8];
						int currentColumnIndex = y;
						if (Preferences.ReversedOrder)
						{
							currentColumnIndex = 7 - y;
						}
					
						for (int x = 0; x < 8; x++)
						{
							if (CurrentSprite.Data[x,currentColumnIndex] > 0)
							{
								rowBinaryValue[x] = '1';
							}
							else
							{
								rowBinaryValue[x] = '0';
							}
						}
					
						if (Preferences.OutputHexData)
						{
							sw.Write(BinToHex(rowBinaryValue));
							if (y < 7)
							{
								sw.Write(",$");
							}
						}
						else
						{
							sw.WriteLine(rowBinaryValue);
							if (y < 7)
							{
								sw.Write("	.byte %");
							}	
						}
					}

					sw.WriteLine();
					if (Preferences.OutputColorData)
					{
						sw.WriteLine("colors");
						sw.Write("	.byte ");
						if (Preferences.OutputHexData)
						{
							sw.Write("$");
						}
						else
						{
							sw.Write("%");
						}
						
						for (int y = 0; y < 8; y++)
						{
							int currentColumnIndex = y;
							if (Preferences.ReversedOrder)
							{
								currentColumnIndex = 7 - y;
							}
							
							int currentColorValue = RowColor[currentColumnIndex] * 2;
							if (Preferences.OutputHexData)
							{

								sw.Write(DecToHex(currentColorValue));
								if (y < 7)
								{
									sw.Write(",$");
								}
							}
							else
							{
								sw.WriteLine(DecToBin(currentColorValue));
								if (y < 7)
								{
									sw.Write("	.byte %");
								}
							}
						}

						if (Preferences.OutputHexData)
						{
							sw.WriteLine();
						}

						sw.WriteLine();
					}
					if (asProgram)
					{
						sw.WriteLine("	org $F7FC");
						sw.WriteLine("	.word Start ");
						sw.WriteLine("	.word Start");
						sw.WriteLine("	org $FFFC");
						sw.WriteLine("	.word Start");
						sw.WriteLine("	.word Start");
					}
		
					sw.Close();
				}
			}
			else
			{
				MessageBox.Show("No sprite file path specified!", "Critial Error", MessageBoxButtons.OK,
					MessageBoxIcon.Error);
			}
		}

		private bool VerifyDirty()
		{
			bool cont = !IsDirty;
			if (IsDirty)
			{
				cont = MessageBox.Show("Discard changes?", "Discard Changes", MessageBoxButtons.YesNo,
					MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes;
			}

			return cont;
		}

		private void DrawCell(int x, int y, Graphics g)
		{
			// Draw large cell
			SolidBrush cellBrush = new SolidBrush(Palette[GetVideoType(), CurrentSprite.Data[x,y]]);
			g.FillRectangle(cellBrush, (x * CellSize) + 1, (y * CellSize) + 1, CellSize - 2, CellSize - 2);
			// Draw small sprite cell
			g.FillRectangle(cellBrush, SmallGridX + (x * SmallCellSize), SmallGridY + (y * SmallCellSize),
				SmallCellSize, SmallCellSize);

		}

		private void DrawRowColorCell(int y, Graphics g)
		{
			// Draw row color
			SolidBrush rowBrush = new SolidBrush(Palette[GetVideoType(), RowColor[y]]);
			g.FillRectangle(rowBrush, GridSize + 3, (y * CellSize) + 10, 9, 40);
		}

		private byte GetVideoType()
		{
			// Get current graphics type
			byte videoType = 0;
			if (Preferences.PalVideo)
			{
				videoType = 1;
			}

			return videoType;
		}

		private string BinToHex(char[] binValue)
		{
			string binString = new string(binValue);
			string hexValue = string.Empty;
			for (int count = 0; count < 2; count++)
			{
				switch (binString.Substring(count * 4, 4))
				{
					case "0000":
						hexValue += '0';
						break;
					case "0001":
						hexValue += '1';
						break;
					case "0010":
						hexValue += '2';
						break;
					case "0011":
						hexValue += '3';
						break;
					case "0100":
						hexValue += '4';
						break;
					case "0101":
						hexValue += '5';
						break;
					case "0110":
						hexValue += '6';
						break;
					case "0111":
						hexValue += '7';
						break;
					case "1000":
						hexValue += '8';
						break;
					case "1001":
						hexValue += '9';
						break;
					case "1010":
						hexValue += 'A';
						break;
					case "1011":
						hexValue += 'B';
						break;
					case "1100":
						hexValue += 'C';
						break;
					case "1101":
						hexValue += 'D';
						break;
					case "1110":
						hexValue += 'E';
						break;
					case "1111":
						hexValue += 'F';
						break;
				}
			}
			return hexValue;
		}

		private string DecToHex(int i)
		{
			string decValue = string.Empty;
			for (int count = 0; count < 2; count++)
			{
				int calc = 0;
				if (count == 0)
				{
					calc = i / 16;
				}
				else
				{
					calc = i % 16;
				}

				switch (calc)
				{
					case 0:
						decValue += '0';
						break;
					case 1:
						decValue += '1';
						break;
					case 2:
						decValue += '2';
						break;
					case 3:
						decValue += '3';
						break;
					case 4:
						decValue += '4';
						break;
					case 5:
						decValue += '5';
						break;
					case 6:
						decValue += '6';
						break;
					case 7:
						decValue += '7';
						break;
					case 8:
						decValue += '8';
						break;
					case 9:
						decValue += '9';
						break;
					case 10:
						decValue += 'A';
						break;
					case 11:
						decValue += 'B';
						break;
					case 12:
						decValue += 'C';
						break;
					case 13:
						decValue += 'D';
						break;
					case 14:
						decValue += 'E';
						break;
					case 15:
						decValue += 'F';
						break;
				}
			}

			return decValue;
		}

		private string DecToBin(int i)
		{
			string binValue = string.Empty;
			for (int power = 7; power >= 0; power--)
			{
				int temp = i / Convert.ToInt32(Math.Pow(2,power));
				binValue += temp.ToString();
				i = i % Convert.ToInt32(Math.Pow(2,power));
			}

			return binValue;
		}

		private void SetLabelValues()
		{
			if (Preferences.OutputColorData)
			{
				lblOutputType.Text = "Sprite+Color Data";
			}
			else
			{
				lblOutputType.Text = "Sprite Data Only";
			}

			if (Preferences.ReversedOrder)
			{
				lblDataOrder.Text = "Reversed Order";
			}
			else
			{
				lblDataOrder.Text = "Nonreversed Order";
			}

			if (Preferences.OutputHexData)
			{
				lblOutputDataType.Text = "Hexadecimal Data";
			}
			else
			{
				lblOutputDataType.Text = "Binary Data";
			}

			if (Preferences.PalVideo)
			{
				lblVideoType.Text = "PAL";
			}
			else
			{
				lblVideoType.Text = "NTSC";
			}
		}
	}
}
