using System;

namespace Junkosoft.AssembleROM
{
	/// <summary>
	/// This class is used to store the preferences
	/// </summary>
	public class Preferences
	{
		#region Private Fields
		private static bool _showToolbar;                   // Show the tool bar
		private static bool _showStatusbar;					// Show the status bar
        private static bool _showOutput;					// Show the output window
        private static string _dasmPath;                    // Path the the DASM Executable
        private static string _makewavPath;                 // Path the the MAKEWAV Executable
        private static string _stellaPath;                  // Path the the Stella Executable
		#endregion
		
		#region Properties
		/// <summary>
        /// Gets or sets whether the tool bar is shown or not
		/// </summary>
		public static bool ShowToolbar
		{
			get 
			{
                return _showToolbar;
			}
			set
			{
                _showToolbar = value;
			}
		}

		/// <summary>
		/// Gets or sets whether the status bar is shown or not
		/// </summary>
		public static bool ShowStatusBar
		{
			get
			{
                return _showStatusbar;
			}
			set
			{
                _showStatusbar = value;
			}
		}

        /// <summary>
        /// Gets or sets whether the output bar is shown or not
        /// </summary>
        public static bool ShowOutputBar
        {
            get
            {
                return _showOutput;
            }
            set
            {
                _showOutput = value;
            }
        }

        /// <summary>
        /// Gets or sets the path to the dasm executable
        /// </summary>
        public static string DasmPath
        {
            get
            {
                return _dasmPath;
            }
            set
            {
                _dasmPath = value;
            }
        }

        /// <summary>
        /// Gets or sets the path to the makewav executable
        /// </summary>
        public static string MakewavPath
        {
            get
            {
                return _makewavPath;
            }
            set
            {
                _makewavPath = value;
            }
        }

        /// <summary>
        /// Gets or sets the path to the stella executable
        /// </summary>
        public static string StellaPath
        {
            get
            {
                return _stellaPath;
            }
            set
            {
                _stellaPath = value;
            }
        }
        #endregion

		#region Public Methods
		public static void GetPreferences()
		{
			try
			{
				Microsoft.Win32.RegistryKey key;
				key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\\Junkosoft\\JunkDev", false);
                _showStatusbar = bool.Parse(key.GetValue("ShowStatus").ToString().ToLower());
                _showToolbar = bool.Parse(key.GetValue("ShowToolbar").ToString().ToLower());
                _showOutput = bool.Parse(key.GetValue("ShowOutput").ToString().ToLower());
                _dasmPath = key.GetValue("DasmPath").ToString();
                _makewavPath = key.GetValue("MakeWavPath").ToString();
                _stellaPath = key.GetValue("StellaPath").ToString();
            }
			catch
			{
				DoPreferencesReset();
			}
		}

		public static void SetPreferences()
		{
			Microsoft.Win32.RegistryKey key;
            key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\\Junkosoft\\JunkDev", true);
			key.SetValue("ShowStatus", _showStatusbar);
			key.SetValue("ShowToolbar", _showToolbar);
            key.SetValue("ShowOutput", _showOutput);
            key.SetValue("DasmPath", _dasmPath);
            key.SetValue("MakeWavPath", _makewavPath);
            key.SetValue("StellaPath", _stellaPath);
		}
		#endregion

		#region Private Methods
		private static void DoPreferencesReset()
		{
			_showStatusbar = true;
			_showToolbar = true;
            _showOutput = true;
            _dasmPath = string.Empty;
            _makewavPath = string.Empty;
            _stellaPath = string.Empty;
            Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Software\\Junkosoft\\JunkDev");
			SetPreferences();
		}
		#endregion
	}
}