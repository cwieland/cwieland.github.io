using System;
using System.IO;
using System.Windows.Forms;

namespace Junkosoft.AssembleROM
{
    public partial class Options : Form
    {
        public Options()
        {
            InitializeComponent();
        }

        private void Options_Load(object sender, EventArgs e)
        {
            Preferences.GetPreferences();
            txtDasmPath.Text = Preferences.DasmPath;
            txtStellaPath.Text = Preferences.StellaPath;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (CheckPaths())
            {
                Preferences.DasmPath = txtDasmPath.Text;
                Preferences.StellaPath = txtStellaPath.Text;
                Preferences.SetPreferences();
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBrowseDasm_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "DASM.EXE";
            openFileDialog1.Filter = "DASM Executable|DASM.EXE";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtDasmPath.Text = openFileDialog1.FileName;
            }
        }

        private void btnBrowseStella_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "STELLA.EXE";
            openFileDialog1.Filter = "Stella Emulator|STELLA.EXE";
            if (Directory.Exists(@"C:\Program Files\Stella"))
            {
                openFileDialog1.InitialDirectory = @"C:\Program Files\Stella";
            }
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtStellaPath.Text = openFileDialog1.FileName;
            }
        }

        private bool CheckPaths()
        {
            // Check DASM path
            bool dasmValid = false;
            if (txtDasmPath.Text.Length > 0)
            {
                dasmValid = File.Exists(txtDasmPath.Text);
            }
            if (!dasmValid)
            {
                MessageBox.Show("DASM path is not valid", "Unable to save changes", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Check Stella path
            bool stellaValid = false;
            if (txtStellaPath.Text.Length > 0)
            {
                stellaValid = File.Exists(txtStellaPath.Text);
            }
            if (!stellaValid)
            {
                MessageBox.Show("Stella path is not valid", "Unable to save changes", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dasmValid && stellaValid;
        }
    }
}