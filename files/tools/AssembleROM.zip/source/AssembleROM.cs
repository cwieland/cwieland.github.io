﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace Junkosoft.AssembleROM
{
    public partial class AssembleROM : Form
    {
        public AssembleROM()
        {
            InitializeComponent();
        }

        private void AssembleROM_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }

        protected void AssembleROM_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData("FileDrop", true);
            if (files != null && files.Length > 0)
            {
                txtFilePath.Text = files[0];
            }
        }

        private void btnOptions_Click(object sender, EventArgs e)
        {
            using (Options dialog = new Options())
            {
                dialog.ShowDialog();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            // Show the load file dialog
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtFilePath.Text = openFileDialog1.FileName;
            }
        }

        private void btnAssemble_Click(object sender, EventArgs e)
        {
            if (AssembleFile())
            {
                RunWithEmulator();
            }
        }

        public bool AssembleFile()
        {
            bool assembleOk = false;

            // Make sure the dasm path is definded
            if (string.IsNullOrEmpty(Preferences.DasmPath))
            {
                MessageBox.Show("DASM path is not defined.\nSelect Tools/Options to define it.",
                    "Unable to assemble file", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (File.Exists(txtFilePath.Text))
                {
                    // Run dasm %1 -f3 -v2 -o%1.bin
                    using (Process proc = new Process())
                    {
                        proc.StartInfo.CreateNoWindow = true;
                        proc.StartInfo.FileName = Preferences.DasmPath;
                        proc.StartInfo.Arguments = "\"" + txtFilePath.Text + "\" -f3 -v2 \"-o" +
                            txtFilePath.Text.Substring(0, txtFilePath.Text.LastIndexOf(".")) + ".bin\" \"-s" +
                            txtFilePath.Text.Substring(0, txtFilePath.Text.LastIndexOf(".")) + ".sym\""; ;
                        proc.StartInfo.RedirectStandardOutput = true;
                        proc.StartInfo.RedirectStandardError = true;
                        proc.StartInfo.UseShellExecute = false;
                        proc.StartInfo.WorkingDirectory = txtFilePath.Text.Substring(0, txtFilePath.Text.LastIndexOf('\\'));
                        proc.Start();

                        // Wait until process has completed
                        while (!proc.HasExited) { }

                        // Return the output and the status back from external process

                        txtOutput.Text = proc.StandardOutput.ReadToEnd();
                        txtOutput.Text += proc.StandardError.ReadToEnd();
                        assembleOk = proc.ExitCode == 0;

                        // Display exit code if not zero
                        if (proc.ExitCode > 0)
                        {
                            MessageBox.Show("DASM exited with an exit code of " + proc.ExitCode + "\nSee output panel for more details.", "Unable to assemble");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Specified source file does not exist.",
                    "Unable to assemble file", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            // Return success status
            return assembleOk;
        }

        public bool RunWithEmulator()
        {
            bool assembleOk = false;

            // Make sure the makewav path is definded
            if (string.IsNullOrEmpty(Preferences.StellaPath))
            {
                MessageBox.Show("STELLA path is not defined.\nSelect Tools/Options to define it.",
                    "Unable to open emulator", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (AssembleFile())
                {
                    // Run stella %1
                    using (Process proc = new Process())
                    {
                        proc.StartInfo.FileName = Preferences.StellaPath;
                        proc.StartInfo.Arguments = "\"" + txtFilePath.Text.Substring(0, txtFilePath.Text.LastIndexOf(".")) + ".bin\"";
                        proc.StartInfo.WorkingDirectory = txtFilePath.Text.Substring(0, txtFilePath.Text.LastIndexOf('\\'));
                        proc.Start();
                        assembleOk = true;
                    }
                }
            }

            // Return success status
            return assembleOk;
        }

        private void AssembleROM_Load(object sender, EventArgs e)
        {
            Preferences.GetPreferences();
        }
    }
}
